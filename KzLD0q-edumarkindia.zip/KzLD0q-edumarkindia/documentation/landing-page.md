# Landing Page

The landing page (all files in the /(landing) folder) use only tailwind css. So do not import components from ant design if you are working in (/landing) file, use tailwind css.

When making design changes, you can make the changes in each component (LandingFeatures, LandingCTA etc..) so check where the change is located and select the right file to make your tailwind changes.
