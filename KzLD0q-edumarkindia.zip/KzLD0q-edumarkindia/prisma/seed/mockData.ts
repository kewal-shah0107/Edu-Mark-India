import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

const splitSql = (sql: string) => {
  return sql.split(';').filter(content => content.trim() !== '')
}

async function main() {
  const sql = `

INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('868e6342-6221-4a95-81ab-9e396da75608', '1Darius_Kerluke-Stamm@hotmail.com', 'Bob Brown', 'https://i.imgur.com/YfJQV5z.png?id=3', 'invfghij', false, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('01d2277a-c120-4bc8-8533-9ddf3e941706', '10Kelley_Metz@yahoo.com', 'John Doe', 'https://i.imgur.com/YfJQV5z.png?id=12', 'invklmno', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('ed4e64d5-bf0f-459c-b9e2-bcaf1885e169', '19Anissa77@hotmail.com', 'Jane Smith', 'https://i.imgur.com/YfJQV5z.png?id=21', 'invklmno', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('f98c03a0-4038-4571-b372-0b649b0453e7', '28Maverick_Gusikowski@hotmail.com', 'Bob Brown', 'https://i.imgur.com/YfJQV5z.png?id=30', 'invabcde', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('b8f54cbf-3ff2-449c-848b-e52f61d297cf', '46Terence97@gmail.com', 'Bob Brown', 'https://i.imgur.com/YfJQV5z.png?id=48', 'invfghij', false, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('e096e379-be46-4a81-9239-d37792303092', '55Felicita_Dare26@hotmail.com', 'Bob Brown', 'https://i.imgur.com/YfJQV5z.png?id=57', 'invfghij', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('ad753289-ee45-4e3c-9b02-7ed548b9de68', '64Muhammad92@yahoo.com', 'Charlie Davis', 'https://i.imgur.com/YfJQV5z.png?id=66', 'invfghij', false, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('829a3e35-0e11-41a9-aa71-572d89c5ee21', '73Eloise51@yahoo.com', 'John Doe', 'https://i.imgur.com/YfJQV5z.png?id=75', 'inv12345', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('bceeee81-69dd-46ee-bf8f-49d16c62feb0', '82Horace_Nikolaus11@yahoo.com', 'Alice Jones', 'https://i.imgur.com/YfJQV5z.png?id=84', 'invfghij', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('7271a7f3-e2f8-43e3-b123-36ea804d478b', 'Knowledge Hub', 'https://i.imgur.com/YfJQV5z.png?id=92');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('9ef12f9c-afa6-4a02-aba6-82cd27a6e454', 'Knowledge Hub', 'https://i.imgur.com/YfJQV5z.png?id=95');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('9de6e8c3-1086-40b2-949b-6aec0b41f1aa', 'Global Learning Solutions', 'https://i.imgur.com/YfJQV5z.png?id=98');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('7007c7be-ff29-4983-b6f4-fb310f182b64', 'Skill Masters', 'https://i.imgur.com/YfJQV5z.png?id=101');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('df881550-e0a1-488d-a2cd-834f1d586c98', 'Tech Innovators Inc.', 'https://i.imgur.com/YfJQV5z.png?id=104');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('d27e33a8-f65d-4f22-9598-1cff86483b51', 'Knowledge Hub', 'https://i.imgur.com/YfJQV5z.png?id=107');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('f9ad34dd-8b2a-4b7e-9fee-abb221c04db5', 'Tech Innovators Inc.', 'https://i.imgur.com/YfJQV5z.png?id=110');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('889bc394-a5c7-4fed-bec6-53ee493a2e35', 'Knowledge Hub', 'https://i.imgur.com/YfJQV5z.png?id=113');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('b23bc8af-0856-4c15-81be-de874b5ef2a0', 'EduTech Enterprises', 'https://i.imgur.com/YfJQV5z.png?id=116');
INSERT INTO "Organization" ("id", "name", "pictureUrl") VALUES ('78fd74e8-54c6-4fb7-bc64-eee09e577d7e', 'EduTech Enterprises', 'https://i.imgur.com/YfJQV5z.png?id=119');

INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('82f28f03-97b9-4645-a3f6-0b051703e3f1', 'Instructor', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'b23bc8af-0856-4c15-81be-de874b5ef2a0');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('fd39261e-5201-4cc5-b616-72062e5f8f4d', 'Student', 'bceeee81-69dd-46ee-bf8f-49d16c62feb0', '7007c7be-ff29-4983-b6f4-fb310f182b64');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('41207436-2070-48a3-82fe-63c4ce8e92bf', 'Instructor', '829a3e35-0e11-41a9-aa71-572d89c5ee21', '9de6e8c3-1086-40b2-949b-6aec0b41f1aa');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('361357a4-c42c-4a52-b2f0-d917415cd8e5', 'Student', 'ed4e64d5-bf0f-459c-b9e2-bcaf1885e169', 'f9ad34dd-8b2a-4b7e-9fee-abb221c04db5');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('1e75a577-243f-4b22-b75e-989ce4b14ba8', 'Content Creator', '01d2277a-c120-4bc8-8533-9ddf3e941706', '9de6e8c3-1086-40b2-949b-6aec0b41f1aa');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('bd1b97ae-0234-4e28-82cb-a66e59bc0917', 'Instructor', 'bceeee81-69dd-46ee-bf8f-49d16c62feb0', '889bc394-a5c7-4fed-bec6-53ee493a2e35');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('ec8b540a-a7ef-47d1-a6d4-a98012ad26ba', 'Administrator', 'e096e379-be46-4a81-9239-d37792303092', '9ef12f9c-afa6-4a02-aba6-82cd27a6e454');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('99e82dc2-2efb-481c-8fe8-f0b5a76fa848', 'Quality Assurance', 'ad753289-ee45-4e3c-9b02-7ed548b9de68', 'df881550-e0a1-488d-a2cd-834f1d586c98');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('c1f05358-b05b-4bf8-822d-61796eff82ab', 'Instructor', 'ad753289-ee45-4e3c-9b02-7ed548b9de68', 'df881550-e0a1-488d-a2cd-834f1d586c98');
INSERT INTO "OrganizationRole" ("id", "name", "userId", "organizationId") VALUES ('6679ef42-0aff-473e-add0-bff48c4c9554', 'Administrator', 'ad753289-ee45-4e3c-9b02-7ed548b9de68', '889bc394-a5c7-4fed-bec6-53ee493a2e35');

INSERT INTO "Course" ("id", "title", "description", "organizationId") VALUES ('daf9c5e9-efd5-4c46-b8f6-7e40c7ce4233', 'Web Development Bootcamp', 'Explore advanced machine learning algorithms and their applications.', '9de6e8c3-1086-40b2-949b-6aec0b41f1aa');
INSERT INTO "Course" ("id", "title", "description", "organizationId") VALUES ('2509ba12-f5a0-4100-8bd8-c7d72951188d', 'Advanced Machine Learning Techniques', 'Understand the fundamentals of digital marketing and how to apply them.', '9ef12f9c-afa6-4a02-aba6-82cd27a6e454');
INSERT INTO "Course" ("id", "title", "description", "organizationId") VALUES ('8d861881-8b00-4f1a-8da4-ddab937cad92', 'Digital Marketing Essentials', 'Explore advanced machine learning algorithms and their applications.', '889bc394-a5c7-4fed-bec6-53ee493a2e35');
INSERT INTO "Course" ("id", "title", "description", "organizationId") VALUES ('664e5b3c-cf05-4261-92e1-98b986a6e8ff', 'Digital Marketing Essentials', 'Explore advanced machine learning algorithms and their applications.', '78fd74e8-54c6-4fb7-bc64-eee09e577d7e');
INSERT INTO "Course" ("id", "title", "description", "organizationId") VALUES ('6b908440-b709-4dd4-8ebb-760a8c0ed5ed', 'Advanced Machine Learning Techniques', 'Become a fullstack web developer with this intensive bootcamp.', '889bc394-a5c7-4fed-bec6-53ee493a2e35');
INSERT INTO "Course" ("id", "title", "description", "organizationId") VALUES ('e9065c42-418b-49e9-bb1f-5b0f51d41504', 'Advanced Machine Learning Techniques', 'Understand the fundamentals of digital marketing and how to apply them.', '7007c7be-ff29-4983-b6f4-fb310f182b64');
INSERT INTO "Course" ("id", "title", "description", "organizationId") VALUES ('d7537097-9431-4d8e-9608-6df27569427a', 'Mastering Data Science with R', 'Become a fullstack web developer with this intensive bootcamp.', '78fd74e8-54c6-4fb7-bc64-eee09e577d7e');
INSERT INTO "Course" ("id", "title", "description", "organizationId") VALUES ('95cdd3a1-0b44-4d0a-b126-a7705843fa6d', 'Digital Marketing Essentials', 'Become a fullstack web developer with this intensive bootcamp.', '9de6e8c3-1086-40b2-949b-6aec0b41f1aa');
INSERT INTO "Course" ("id", "title", "description", "organizationId") VALUES ('e19cdd7c-b026-49f5-838d-e86c6b482ca8', 'Introduction to Python Programming', 'Explore advanced machine learning algorithms and their applications.', '9ef12f9c-afa6-4a02-aba6-82cd27a6e454');
INSERT INTO "Course" ("id", "title", "description", "organizationId") VALUES ('3f0bf506-db65-4602-9f76-925e2189cb81', 'Mastering Data Science with R', 'Learn the basics of Python programming in this comprehensive course.', 'd27e33a8-f65d-4f22-9598-1cff86483b51');

INSERT INTO "Lesson" ("id", "title", "content", "orderIndex", "courseId") VALUES ('6d6550a3-138c-4958-b1a5-b140684c2704', 'Data Science with R', 'Master the strategies of digital marketing.', 851, 'daf9c5e9-efd5-4c46-b8f6-7e40c7ce4233');
INSERT INTO "Lesson" ("id", "title", "content", "orderIndex", "courseId") VALUES ('5eb65b5a-7552-46e5-932a-08f6f33c6b73', 'Data Science with R', 'Master the strategies of digital marketing.', 311, '8d861881-8b00-4f1a-8da4-ddab937cad92');
INSERT INTO "Lesson" ("id", "title", "content", "orderIndex", "courseId") VALUES ('9dbf0636-d775-4f26-8a2c-d005039e077a', 'Digital Marketing Strategies', 'Master the strategies of digital marketing.', 374, 'd7537097-9431-4d8e-9608-6df27569427a');
INSERT INTO "Lesson" ("id", "title", "content", "orderIndex", "courseId") VALUES ('7aa8ec2b-5a9e-4452-b60c-eb2669726d1d', 'Web Development Basics', 'Explore advanced techniques in machine learning.', 549, '3f0bf506-db65-4602-9f76-925e2189cb81');
INSERT INTO "Lesson" ("id", "title", "content", "orderIndex", "courseId") VALUES ('a7d52acf-f9f1-4192-a97a-9ed5d2435da4', 'Digital Marketing Strategies', 'Dive into data science using the R programming language.', 196, '95cdd3a1-0b44-4d0a-b126-a7705843fa6d');
INSERT INTO "Lesson" ("id", "title", "content", "orderIndex", "courseId") VALUES ('a381d1c4-fc9b-41f8-8b6a-a44df98c9d0d', 'Introduction to Python', 'Learn the basics of Python programming.', 121, '3f0bf506-db65-4602-9f76-925e2189cb81');
INSERT INTO "Lesson" ("id", "title", "content", "orderIndex", "courseId") VALUES ('c9140a75-e378-4fa7-8116-69d09e2ec7ff', 'Digital Marketing Strategies', 'Dive into data science using the R programming language.', 965, 'd7537097-9431-4d8e-9608-6df27569427a');
INSERT INTO "Lesson" ("id", "title", "content", "orderIndex", "courseId") VALUES ('85817805-0de9-4898-8536-fd6446f94140', 'Digital Marketing Strategies', 'Understand the fundamentals of web development.', 617, '3f0bf506-db65-4602-9f76-925e2189cb81');
INSERT INTO "Lesson" ("id", "title", "content", "orderIndex", "courseId") VALUES ('18f45d91-9a28-4afb-b610-b595491fc27f', 'Digital Marketing Strategies', 'Learn the basics of Python programming.', 548, 'e9065c42-418b-49e9-bb1f-5b0f51d41504');
INSERT INTO "Lesson" ("id", "title", "content", "orderIndex", "courseId") VALUES ('e1512463-c8c7-457f-930f-399b2cd65ce9', 'Advanced Machine Learning', 'Master the strategies of digital marketing.', 924, '6b908440-b709-4dd4-8ebb-760a8c0ed5ed');

INSERT INTO "Enrollment" ("id", "enrollmentDate", "status", "userId", "courseId") VALUES ('acaa429b-563f-45cc-b163-90ea6e5aef07', '2025-06-22T11:22:36.411Z', 'cancelled', '01d2277a-c120-4bc8-8533-9ddf3e941706', 'e9065c42-418b-49e9-bb1f-5b0f51d41504');
INSERT INTO "Enrollment" ("id", "enrollmentDate", "status", "userId", "courseId") VALUES ('bcffeb19-b85e-44b7-8422-7942d27b6f75', '2025-04-20T02:22:38.158Z', 'completed', 'b8f54cbf-3ff2-449c-848b-e52f61d297cf', '2509ba12-f5a0-4100-8bd8-c7d72951188d');
INSERT INTO "Enrollment" ("id", "enrollmentDate", "status", "userId", "courseId") VALUES ('7b64ee7c-fd80-428c-82d7-a53aa191d6a7', '2024-06-28T02:58:20.034Z', 'completed', 'ed4e64d5-bf0f-459c-b9e2-bcaf1885e169', 'e19cdd7c-b026-49f5-838d-e86c6b482ca8');
INSERT INTO "Enrollment" ("id", "enrollmentDate", "status", "userId", "courseId") VALUES ('223e3068-dd9a-49b7-bd83-b7f4dceaf2ba', '2023-10-09T12:44:41.304Z', 'failed', '01d2277a-c120-4bc8-8533-9ddf3e941706', '8d861881-8b00-4f1a-8da4-ddab937cad92');
INSERT INTO "Enrollment" ("id", "enrollmentDate", "status", "userId", "courseId") VALUES ('ca60eac0-26fd-4c76-a630-d0ed2fe07fb3', '2024-05-23T18:36:38.433Z', 'active', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '3f0bf506-db65-4602-9f76-925e2189cb81');
INSERT INTO "Enrollment" ("id", "enrollmentDate", "status", "userId", "courseId") VALUES ('42edae59-8232-4d7e-865f-f2febcf5dde7', '2024-09-01T15:42:19.074Z', 'failed', '829a3e35-0e11-41a9-aa71-572d89c5ee21', 'e19cdd7c-b026-49f5-838d-e86c6b482ca8');
INSERT INTO "Enrollment" ("id", "enrollmentDate", "status", "userId", "courseId") VALUES ('d9ce3d4d-b495-40b3-9c6b-0761fadaf09b', '2023-10-05T16:44:42.056Z', 'pending', 'e096e379-be46-4a81-9239-d37792303092', '6b908440-b709-4dd4-8ebb-760a8c0ed5ed');
INSERT INTO "Enrollment" ("id", "enrollmentDate", "status", "userId", "courseId") VALUES ('33d27dab-88d9-4720-8e9d-cecc59873799', '2024-07-04T17:11:38.821Z', 'failed', '829a3e35-0e11-41a9-aa71-572d89c5ee21', 'daf9c5e9-efd5-4c46-b8f6-7e40c7ce4233');
INSERT INTO "Enrollment" ("id", "enrollmentDate", "status", "userId", "courseId") VALUES ('c8b53018-aa67-4436-b53b-7450481fbd05', '2025-06-22T12:29:57.000Z', 'completed', 'f98c03a0-4038-4571-b372-0b649b0453e7', '3f0bf506-db65-4602-9f76-925e2189cb81');
INSERT INTO "Enrollment" ("id", "enrollmentDate", "status", "userId", "courseId") VALUES ('057aa14e-6da6-4fa6-b125-3cf5ce763391', '2025-06-28T07:48:58.878Z', 'active', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '6b908440-b709-4dd4-8ebb-760a8c0ed5ed');

INSERT INTO "Progress" ("id", "completionDate", "status", "enrollmentId", "lessonId") VALUES ('9798214d-98b9-47af-9c6d-79e6d049aa35', '2025-09-06T19:35:23.334Z', 'On Hold', 'acaa429b-563f-45cc-b163-90ea6e5aef07', 'e1512463-c8c7-457f-930f-399b2cd65ce9');
INSERT INTO "Progress" ("id", "completionDate", "status", "enrollmentId", "lessonId") VALUES ('71e7bab9-3253-4a58-84c4-61a1ad028bee', '2023-10-21T04:58:44.011Z', 'Not Started', '33d27dab-88d9-4720-8e9d-cecc59873799', 'c9140a75-e378-4fa7-8116-69d09e2ec7ff');
INSERT INTO "Progress" ("id", "completionDate", "status", "enrollmentId", "lessonId") VALUES ('77bc20e2-1ed4-4f61-a28b-446c705f9943', '2025-06-04T02:13:01.373Z', 'Cancelled', 'ca60eac0-26fd-4c76-a630-d0ed2fe07fb3', '5eb65b5a-7552-46e5-932a-08f6f33c6b73');
INSERT INTO "Progress" ("id", "completionDate", "status", "enrollmentId", "lessonId") VALUES ('fb9220dc-6b97-49a9-ac2a-03b5ece51e15', '2025-07-25T22:57:15.987Z', 'On Hold', 'ca60eac0-26fd-4c76-a630-d0ed2fe07fb3', 'c9140a75-e378-4fa7-8116-69d09e2ec7ff');
INSERT INTO "Progress" ("id", "completionDate", "status", "enrollmentId", "lessonId") VALUES ('a3aff0a0-00ac-4aff-9036-43a6675a7695', '2024-06-17T11:16:33.208Z', 'Not Started', 'bcffeb19-b85e-44b7-8422-7942d27b6f75', 'e1512463-c8c7-457f-930f-399b2cd65ce9');
INSERT INTO "Progress" ("id", "completionDate", "status", "enrollmentId", "lessonId") VALUES ('a99f61aa-a3a2-44d4-bcc8-672ff3fa0ca3', '2024-07-31T01:55:08.419Z', 'Cancelled', 'ca60eac0-26fd-4c76-a630-d0ed2fe07fb3', 'c9140a75-e378-4fa7-8116-69d09e2ec7ff');
INSERT INTO "Progress" ("id", "completionDate", "status", "enrollmentId", "lessonId") VALUES ('867695cd-c23e-4883-9359-682d4569ca17', '2024-05-21T18:56:16.379Z', 'Completed', 'c8b53018-aa67-4436-b53b-7450481fbd05', '9dbf0636-d775-4f26-8a2c-d005039e077a');
INSERT INTO "Progress" ("id", "completionDate", "status", "enrollmentId", "lessonId") VALUES ('eec6bede-3680-44ca-aafd-aa9c29eeabe1', '2024-05-21T03:12:32.887Z', 'Cancelled', '057aa14e-6da6-4fa6-b125-3cf5ce763391', '85817805-0de9-4898-8536-fd6446f94140');
INSERT INTO "Progress" ("id", "completionDate", "status", "enrollmentId", "lessonId") VALUES ('e21ab8be-9f87-4c8a-bfc1-947328e306f3', '2025-03-11T14:40:14.756Z', 'Completed', 'acaa429b-563f-45cc-b163-90ea6e5aef07', 'a381d1c4-fc9b-41f8-8b6a-a44df98c9d0d');
INSERT INTO "Progress" ("id", "completionDate", "status", "enrollmentId", "lessonId") VALUES ('bf2e124e-2d93-4c7f-9b7e-83f854d0e701', '2024-06-03T02:06:09.350Z', 'On Hold', 'c8b53018-aa67-4436-b53b-7450481fbd05', '9dbf0636-d775-4f26-8a2c-d005039e077a');

INSERT INTO "Certificate" ("id", "issueDate", "certificateUrl", "enrollmentId") VALUES ('1061c5de-7bf5-4df8-a49e-327501d7594a', '2024-04-29T08:45:03.096Z', 'https://i.imgur.com/YfJQV5z.png?id=272', '057aa14e-6da6-4fa6-b125-3cf5ce763391');
INSERT INTO "Certificate" ("id", "issueDate", "certificateUrl", "enrollmentId") VALUES ('376f0e8a-514d-4b58-94ef-9a5e2a33905f', '2023-10-22T07:42:31.073Z', 'https://i.imgur.com/YfJQV5z.png?id=275', '057aa14e-6da6-4fa6-b125-3cf5ce763391');
INSERT INTO "Certificate" ("id", "issueDate", "certificateUrl", "enrollmentId") VALUES ('b03b5c21-1099-454e-a20e-7f049334ba57', '2024-05-12T03:30:05.318Z', 'https://i.imgur.com/YfJQV5z.png?id=278', 'ca60eac0-26fd-4c76-a630-d0ed2fe07fb3');
INSERT INTO "Certificate" ("id", "issueDate", "certificateUrl", "enrollmentId") VALUES ('243d378f-ac7d-42c3-8f58-e34ff0e9f3db', '2024-02-17T02:21:38.672Z', 'https://i.imgur.com/YfJQV5z.png?id=281', '223e3068-dd9a-49b7-bd83-b7f4dceaf2ba');
INSERT INTO "Certificate" ("id", "issueDate", "certificateUrl", "enrollmentId") VALUES ('b0efeb49-8581-47ff-a113-2feb1211c937', '2024-12-08T22:52:50.763Z', 'https://i.imgur.com/YfJQV5z.png?id=284', '42edae59-8232-4d7e-865f-f2febcf5dde7');
INSERT INTO "Certificate" ("id", "issueDate", "certificateUrl", "enrollmentId") VALUES ('377f0acb-24b3-488e-b997-6fb429923d81', '2024-06-01T19:50:58.715Z', 'https://i.imgur.com/YfJQV5z.png?id=287', 'd9ce3d4d-b495-40b3-9c6b-0761fadaf09b');
INSERT INTO "Certificate" ("id", "issueDate", "certificateUrl", "enrollmentId") VALUES ('cf5cf305-4729-4e7a-9417-511725e679f6', '2023-09-24T11:46:45.133Z', 'https://i.imgur.com/YfJQV5z.png?id=290', 'ca60eac0-26fd-4c76-a630-d0ed2fe07fb3');
INSERT INTO "Certificate" ("id", "issueDate", "certificateUrl", "enrollmentId") VALUES ('5baa8f7b-a673-4cb8-b3c5-a367372bdc47', '2024-01-14T04:20:15.668Z', 'https://i.imgur.com/YfJQV5z.png?id=293', 'bcffeb19-b85e-44b7-8422-7942d27b6f75');
INSERT INTO "Certificate" ("id", "issueDate", "certificateUrl", "enrollmentId") VALUES ('e3728be9-2882-454c-8844-a5d7a6aa54bf', '2025-08-08T18:26:57.230Z', 'https://i.imgur.com/YfJQV5z.png?id=296', '057aa14e-6da6-4fa6-b125-3cf5ce763391');
INSERT INTO "Certificate" ("id", "issueDate", "certificateUrl", "enrollmentId") VALUES ('f9677d0f-63c3-4678-827d-2fed7f4811dc', '2025-02-12T15:41:11.813Z', 'https://i.imgur.com/YfJQV5z.png?id=299', 'c8b53018-aa67-4436-b53b-7450481fbd05');

INSERT INTO "Review" ("id", "rating", "comment", "userId", "courseId") VALUES ('bf84bf56-5bd0-4b8b-97f7-ae312f02937e', 858, 'Didnt meet my expectations too basic.', 'e096e379-be46-4a81-9239-d37792303092', 'e19cdd7c-b026-49f5-838d-e86c6b482ca8');
INSERT INTO "Review" ("id", "rating", "comment", "userId", "courseId") VALUES ('aab88124-7a37-4d15-846a-db0a90219dca', 488, 'Great course learned a lot', '868e6342-6221-4a95-81ab-9e396da75608', 'e9065c42-418b-49e9-bb1f-5b0f51d41504');
INSERT INTO "Review" ("id", "rating", "comment", "userId", "courseId") VALUES ('d879ef47-1c44-474e-bc27-b8fd502ee1a7', 392, 'Great course learned a lot', 'e096e379-be46-4a81-9239-d37792303092', '664e5b3c-cf05-4261-92e1-98b986a6e8ff');
INSERT INTO "Review" ("id", "rating", "comment", "userId", "courseId") VALUES ('394c6760-048e-4854-955d-de165b144148', 209, 'Didnt meet my expectations too basic.', 'b8f54cbf-3ff2-449c-848b-e52f61d297cf', '3f0bf506-db65-4602-9f76-925e2189cb81');
INSERT INTO "Review" ("id", "rating", "comment", "userId", "courseId") VALUES ('b5072f44-0294-487c-9007-98d8e20b00bb', 425, 'It was okay but could use more examples.', '01d2277a-c120-4bc8-8533-9ddf3e941706', '2509ba12-f5a0-4100-8bd8-c7d72951188d');
INSERT INTO "Review" ("id", "rating", "comment", "userId", "courseId") VALUES ('c995e09f-c987-49ec-8965-ab74c9104a86', 154, 'Excellent Highly recommend to others.', 'ed4e64d5-bf0f-459c-b9e2-bcaf1885e169', '6b908440-b709-4dd4-8ebb-760a8c0ed5ed');
INSERT INTO "Review" ("id", "rating", "comment", "userId", "courseId") VALUES ('69d703fd-840c-4b96-b402-1d265df0ae81', 254, 'It was okay but could use more examples.', 'ad753289-ee45-4e3c-9b02-7ed548b9de68', '6b908440-b709-4dd4-8ebb-760a8c0ed5ed');
INSERT INTO "Review" ("id", "rating", "comment", "userId", "courseId") VALUES ('b960d67f-9c5a-49bc-9ca7-275dc165eb65', 937, 'The content was very informative and wellstructured.', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'e9065c42-418b-49e9-bb1f-5b0f51d41504');
INSERT INTO "Review" ("id", "rating", "comment", "userId", "courseId") VALUES ('2a5ed0c4-d881-43ed-b4a0-1661be7208c4', 308, 'Great course learned a lot', 'e096e379-be46-4a81-9239-d37792303092', '3f0bf506-db65-4602-9f76-925e2189cb81');
INSERT INTO "Review" ("id", "rating", "comment", "userId", "courseId") VALUES ('d352fa3c-f446-4737-95ff-e82f35bc1fbb', 16, 'Great course learned a lot', '829a3e35-0e11-41a9-aa71-572d89c5ee21', '95cdd3a1-0b44-4d0a-b126-a7705843fa6d');

INSERT INTO "Payment" ("id", "amount", "paymentDate", "status", "userId", "courseId") VALUES ('b4b2ac47-b204-4a7f-81d7-d1be8db5ae26', 407, '2024-01-09T23:38:28.901Z', 'processing', '868e6342-6221-4a95-81ab-9e396da75608', 'e9065c42-418b-49e9-bb1f-5b0f51d41504');
INSERT INTO "Payment" ("id", "amount", "paymentDate", "status", "userId", "courseId") VALUES ('357514a4-de33-451d-926e-e4ff2857ef8b', 733, '2024-12-29T04:26:27.417Z', 'pending', 'f98c03a0-4038-4571-b372-0b649b0453e7', '664e5b3c-cf05-4261-92e1-98b986a6e8ff');
INSERT INTO "Payment" ("id", "amount", "paymentDate", "status", "userId", "courseId") VALUES ('79ae86a2-47cf-46c8-935c-c5b0cd13f6a1', 355, '2023-10-21T15:12:56.376Z', 'pending', '01d2277a-c120-4bc8-8533-9ddf3e941706', 'e9065c42-418b-49e9-bb1f-5b0f51d41504');
INSERT INTO "Payment" ("id", "amount", "paymentDate", "status", "userId", "courseId") VALUES ('1819959c-439f-402d-9115-0f99e76e3a35', 271, '2025-08-17T10:17:57.637Z', 'refunded', 'ed4e64d5-bf0f-459c-b9e2-bcaf1885e169', 'daf9c5e9-efd5-4c46-b8f6-7e40c7ce4233');
INSERT INTO "Payment" ("id", "amount", "paymentDate", "status", "userId", "courseId") VALUES ('10915709-881e-44ad-b45b-6e951844238c', 219, '2025-07-17T07:38:57.512Z', 'failed', 'bceeee81-69dd-46ee-bf8f-49d16c62feb0', '95cdd3a1-0b44-4d0a-b126-a7705843fa6d');
INSERT INTO "Payment" ("id", "amount", "paymentDate", "status", "userId", "courseId") VALUES ('2762f192-6b50-4699-8e32-2614ad4dd254', 101, '2023-11-21T11:31:49.478Z', 'failed', 'ed4e64d5-bf0f-459c-b9e2-bcaf1885e169', '6b908440-b709-4dd4-8ebb-760a8c0ed5ed');
INSERT INTO "Payment" ("id", "amount", "paymentDate", "status", "userId", "courseId") VALUES ('49d13436-5a69-4995-ad22-b89ea1f84db4', 819, '2025-06-20T16:47:06.672Z', 'refunded', '868e6342-6221-4a95-81ab-9e396da75608', 'e9065c42-418b-49e9-bb1f-5b0f51d41504');
INSERT INTO "Payment" ("id", "amount", "paymentDate", "status", "userId", "courseId") VALUES ('b558a057-b50f-4e86-baf1-d85db1b74b3b', 742, '2024-11-13T21:53:25.211Z', 'refunded', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'e19cdd7c-b026-49f5-838d-e86c6b482ca8');
INSERT INTO "Payment" ("id", "amount", "paymentDate", "status", "userId", "courseId") VALUES ('127c3685-c738-46d6-aa77-753d1d7c3de3', 236, '2024-09-18T04:51:20.937Z', 'refunded', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '6b908440-b709-4dd4-8ebb-760a8c0ed5ed');
INSERT INTO "Payment" ("id", "amount", "paymentDate", "status", "userId", "courseId") VALUES ('89009eca-f6c3-48b6-a3dc-24776f002013', 492, '2024-06-26T20:24:34.716Z', 'pending', 'bceeee81-69dd-46ee-bf8f-49d16c62feb0', 'e19cdd7c-b026-49f5-838d-e86c6b482ca8');

  `

  const sqls = splitSql(sql)

  for (const sql of sqls) {
    try {
      await prisma.$executeRawUnsafe(`${sql}`)
    } catch (error) {
      console.log(`Could not insert SQL: ${error.message}`)
    }
  }
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async error => {
    console.error(error)
    await prisma.$disconnect()
    process.exit(1)
  })
