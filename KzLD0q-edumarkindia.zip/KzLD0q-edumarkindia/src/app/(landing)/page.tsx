'use client'
import { LandingCTA } from '@/designSystem/landing/LandingCTA'
import { LandingContainer } from '@/designSystem/landing/LandingContainer'
import LandingFAQ from '@/designSystem/landing/LandingFAQ'
import { LandingFeatures } from '@/designSystem/landing/LandingFeatures'
import { LandingHero } from '@/designSystem/landing/LandingHero'
import { LandingHowItWorks } from '@/designSystem/landing/LandingHowItWorks'
import { LandingPainPoints } from '@/designSystem/landing/LandingPainPoints'
import { LandingPricing } from '@/designSystem/landing/LandingPricing'
import { LandingSocialProof } from '@/designSystem/landing/LandingSocialProof'
import { LandingSocialRating } from '@/designSystem/landing/LandingSocialRating'
import { LandingTestimonials } from '@/designSystem/landing/LandingTestimonials'
import {
  BookOutlined,
  TeamOutlined,
  TrophyOutlined,
  RocketOutlined,
  GlobalOutlined,
  DollarOutlined,
} from '@ant-design/icons'

export default function LandingPage() {
  const features = [
    {
      heading: `Diverse Course Catalog`,
      description: `Access a wide range of high-quality courses from top instructors across various disciplines.`,
      icon: <BookOutlined />,
    },
    {
      heading: `Expert Instructors`,
      description: `Learn from industry professionals and subject matter experts who are passionate about sharing their knowledge.`,
      icon: <TeamOutlined />,
    },
    {
      heading: `Recognized Certifications`,
      description: `Earn valuable certifications upon course completion to boost your professional profile.`,
      icon: <TrophyOutlined />,
    },
    {
      heading: `Flexible Learning`,
      description: `Study at your own pace, anytime and anywhere, with our mobile-friendly platform.`,
      icon: <RocketOutlined />,
    },
    {
      heading: `Global Community`,
      description: `Connect with learners worldwide, share insights, and expand your network.`,
      icon: <GlobalOutlined />,
    },
    {
      heading: `Affordable Pricing`,
      description: `Access premium education at competitive prices, with various subscription options to suit your needs.`,
      icon: <DollarOutlined />,
    },
  ]

  const testimonials = [
    {
      name: `Sarah Johnson`,
      designation: `Career Changer`,
      content: `EduMarkIndia transformed my career. I went from a stagnant job to a thriving tech role after completing their web development courses. The certifications really made my resume stand out!`,
      avatar: 'https://randomuser.me/api/portraits/women/6.jpg',
    },
    {
      name: `Rahul Patel`,
      designation: `Entrepreneur`,
      content: `As a business owner, I needed to upskill quickly. EduMarkIndia's flexible learning options allowed me to balance my studies with running my company. The ROI has been incredible!`,
      avatar: 'https://randomuser.me/api/portraits/men/7.jpg',
    },
    {
      name: `Emily Chen`,
      designation: `College Student`,
      content: `EduMarkIndia's courses complemented my university studies perfectly. The practical skills I gained gave me a huge advantage in internships and job interviews.`,
      avatar: 'https://randomuser.me/api/portraits/women/27.jpg',
    },
    {
      name: `Michael Brown`,
      designation: `IT Professional`,
      content: `The quality of instruction on EduMarkIndia is unmatched. I've taken courses on other platforms, but the depth of content and instructor engagement here is on another level.`,
      avatar: 'https://randomuser.me/api/portraits/men/12.jpg',
    },
    {
      name: `Priya Sharma`,
      designation: `Teacher`,
      content: `EduMarkIndia not only helped me enhance my teaching skills but also inspired me to create my own course. The platform's tools for instructors are intuitive and powerful.`,
      avatar: 'https://randomuser.me/api/portraits/women/32.jpg',
    },
    {
      name: `David Wilson`,
      designation: `Lifelong Learner`,
      content: `At 65, I thought my learning days were behind me. EduMarkIndia proved me wrong! The courses have kept my mind sharp and opened up a whole new world of knowledge.`,
      avatar: 'https://randomuser.me/api/portraits/men/17.jpg',
    },
  ]

  const navItems = [
    {
      title: `Features`,
      link: `#features`,
    },
    {
      title: `Pricing`,
      link: `#pricing`,
    },
    {
      title: `FAQ`,
      link: `#faq`,
    },
  ]

  const packages = [
    {
      title: `Basic Learner`,
      description: `Perfect for casual learners and beginners`,
      monthly: 9.99,
      yearly: 99,
      features: [
        `Access to 100+ courses`,
        `Basic certifications`,
        `24/7 support`,
      ],
    },
    {
      title: `Pro Learner`,
      description: `Ideal for serious learners and career changers`,
      monthly: 19.99,
      yearly: 199,
      features: [
        `Unlimited course access`,
        `Advanced certifications`,
        `1-on-1 mentoring sessions`,
        `Career counseling`,
      ],
      highlight: true,
    },
    {
      title: `Enterprise`,
      description: `Tailored for businesses and organizations`,
      monthly: 49.99,
      yearly: 499,
      features: [
        `Custom learning paths`,
        `Branded certifications`,
        `Dedicated account manager`,
        `Analytics dashboard`,
      ],
    },
  ]

  const questionAnswers = [
    {
      question: `How do EduMarkIndia certifications compare to traditional qualifications?`,
      answer: `EduMarkIndia certifications are industry-recognized and designed to showcase practical, up-to-date skills. While they may not replace traditional degrees, they complement them by demonstrating your commitment to continuous learning and specific expertise in your field.`,
    },
    {
      question: `Can I access course content offline?`,
      answer: `Yes, our mobile app allows you to download course materials for offline viewing. This feature is available for all subscription tiers, ensuring you can learn even without an internet connection.`,
    },
    {
      question: `What if I'm unsatisfied with a course?`,
      answer: `We offer a 30-day money-back guarantee on all courses. If you're not satisfied, simply contact our support team within 30 days of purchase for a full refund, no questions asked.`,
    },
    {
      question: `How often is course content updated?`,
      answer: `We work closely with our instructors to ensure course content is regularly updated. Most courses are reviewed and updated quarterly, with major updates occurring annually to keep pace with industry changes.`,
    },
  ]

  const logos = [
    { url: 'https://i.imgur.com/afwBIFK.png' },
    { url: 'https://i.imgur.com/LlloOPa.png' },
    { url: 'https://i.imgur.com/j8jPb4H.png' },
    { url: 'https://i.imgur.com/mJ1sZFv.png' },
  ]

  const steps = [
    {
      heading: `Explore Courses`,
      description: `Browse our extensive catalog of courses across various disciplines and skill levels.`,
    },
    {
      heading: `Enroll and Learn`,
      description: `Sign up for courses that match your goals and start learning at your own pace.`,
    },
    {
      heading: `Complete Assignments`,
      description: `Apply your knowledge through practical assignments and quizzes to reinforce learning.`,
    },
    {
      heading: `Earn Certification`,
      description: `Successfully complete your course to receive a recognized certification in your field.`,
    },
  ]

  const painPoints = [
    {
      emoji: `😓`,
      title: `Feeling stuck in your career with outdated skills`,
    },
    {
      emoji: `💸`,
      title: `High costs and time commitments of traditional education`,
    },
    {
      emoji: `🌐`,
      title: `Difficulty finding quality courses that fit your schedule`,
    },
  ]

  const avatarItems = [
    {
      src: 'https://randomuser.me/api/portraits/men/51.jpg',
    },
    {
      src: 'https://randomuser.me/api/portraits/women/9.jpg',
    },
    {
      src: 'https://randomuser.me/api/portraits/women/52.jpg',
    },
    {
      src: 'https://randomuser.me/api/portraits/men/5.jpg',
    },
    {
      src: 'https://randomuser.me/api/portraits/men/4.jpg',
    },
  ]

  return (
    <LandingContainer navItems={navItems}>
      <LandingHero
        title={`Unlock Your Potential with World-Class Online Education`}
        subtitle={`Join millions of learners worldwide in mastering new skills, advancing your career, and achieving your goals through our comprehensive online learning platform.`}
        buttonText={`Start Learning Today`}
        pictureUrl={`https://marblism-dashboard-api--production-public.s3.us-west-1.amazonaws.com/KzLD0q-edumarkindia-Nnkm`}
        socialProof={
          <LandingSocialRating
            avatarItems={avatarItems}
            numberOfUsers={1000000}
            suffixText={`happy learners worldwide`}
          />
        }
      />
      <LandingSocialProof
        logos={logos}
        title={`Trusted by Leading Companies`}
      />
      <LandingPainPoints
        title={`The Challenge of Modern Education: 52% of Students Struggle with Traditional Learning Methods`}
        painPoints={painPoints}
      />
      <LandingHowItWorks
        title={`Your Journey to Success Starts Here`}
        steps={steps}
      />
      <LandingFeatures
        id="features"
        title={`Empower Your Learning Journey with Cutting-Edge Features`}
        subtitle={`Discover how our platform revolutionizes online education to help you achieve your goals faster and more effectively.`}
        features={features}
      />
      <LandingTestimonials
        title={`Success Stories: How Our Learners Transformed Their Lives`}
        subtitle={`Join thousands of satisfied students who have accelerated their careers and personal growth with EduMarkIndia.`}
        testimonials={testimonials}
      />
      <LandingPricing
        id="pricing"
        title={`Invest in Your Future with Flexible Pricing Options`}
        subtitle={`Choose the plan that fits your learning goals and budget. Unlock a world of knowledge and opportunities.`}
        packages={packages}
      />
      <LandingFAQ
        id="faq"
        title={`Got Questions? We've Got Answers`}
        subtitle={`Find quick solutions to your queries about our platform, courses, and certifications.`}
        questionAnswers={questionAnswers}
      />
      <LandingCTA
        title={`Ready to Transform Your Life Through Learning?`}
        subtitle={`Join EduMarkIndia today and take the first step towards a brighter, more successful future. Your journey to excellence begins here!`}
        buttonText={`Enroll Now`}
        buttonLink={`/register`}
      />
    </LandingContainer>
  )
}
