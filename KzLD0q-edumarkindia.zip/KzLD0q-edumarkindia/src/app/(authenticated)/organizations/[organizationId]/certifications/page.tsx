'use client'

import { Typography, Card, List, Button, Progress, Space } from 'antd'
import {
  BookOutlined,
  CheckCircleOutlined,
  TrophyOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function CertificationsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const { data: courses, isLoading } = Api.course.findMany.useQuery({
    where: { organizationId: params.organizationId },
    include: { enrollments: { where: { userId: user?.id } } },
  })

  const { mutateAsync: createEnrollment } = Api.enrollment.create.useMutation()

  const handleStartCertification = async (courseId: string) => {
    try {
      await createEnrollment({
        data: {
          userId: user?.id,
          courseId: courseId,
          status: 'IN_PROGRESS',
        },
      })
      enqueueSnackbar('Certification program started successfully!', {
        variant: 'success',
      })
      router.push(
        `/organizations/${params.organizationId}/courses/${courseId}/learn`,
      )
    } catch (error) {
      enqueueSnackbar('Failed to start certification program', {
        variant: 'error',
      })
    }
  }

  const calculateProgress = (course: any) => {
    if (course.enrollments && course.enrollments.length > 0) {
      const enrollment = course.enrollments[0]
      const totalLessons = course.lessons?.length || 1
      const completedLessons =
        enrollment.progresss?.filter((p: any) => p.status === 'COMPLETED')
          .length || 0
      return Math.round((completedLessons / totalLessons) * 100)
    }
    return 0
  }

  return (
    <PageLayout layout="full-width">
      <Space
        direction="vertical"
        size="large"
        style={{ width: '100%', maxWidth: 800, margin: '0 auto' }}
      >
        <Title level={2}>Certifications</Title>
        <Text>
          View available certifications, start new programs, and track your
          progress.
        </Text>

        {isLoading ? (
          <Text>Loading certifications...</Text>
        ) : (
          <List
            grid={{ gutter: 16, xs: 1, sm: 2, md: 2, lg: 3, xl: 3, xxl: 3 }}
            dataSource={courses}
            renderItem={(course: any) => (
              <List.Item>
                <Card
                  title={
                    <Space>
                      <BookOutlined /> {course.title}
                    </Space>
                  }
                  actions={[
                    course.enrollments && course.enrollments.length > 0 ? (
                      <Button
                        icon={<TrophyOutlined />}
                        onClick={() =>
                          router.push(
                            `/organizations/${params.organizationId}/courses/${course.id}/learn`,
                          )
                        }
                      >
                        Continue
                      </Button>
                    ) : (
                      <Button
                        icon={<CheckCircleOutlined />}
                        onClick={() => handleStartCertification(course.id)}
                      >
                        Start
                      </Button>
                    ),
                  ]}
                >
                  <Text>{course.description}</Text>
                  {course.enrollments && course.enrollments.length > 0 && (
                    <div style={{ marginTop: 16 }}>
                      <Text strong>Progress:</Text>
                      <Progress percent={calculateProgress(course)} />
                    </div>
                  )}
                </Card>
              </List.Item>
            )}
          />
        )}
      </Space>
    </PageLayout>
  )
}
