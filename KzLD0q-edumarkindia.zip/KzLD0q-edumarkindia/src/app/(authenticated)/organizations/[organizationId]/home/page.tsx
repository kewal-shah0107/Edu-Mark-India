'use client'

import { Typography, Input, Card, Row, Col, Progress, Space } from 'antd'
import { SearchOutlined, BookOutlined, TrophyOutlined } from '@ant-design/icons'
import { useState } from 'react'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function HomePage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user, organization } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [searchKeyword, setSearchKeyword] = useState('')

  const { data: featuredCourses, isLoading: isLoadingFeatured } =
    Api.course.findMany.useQuery({
      where: { organizationId: organization?.id },
      take: 3,
      orderBy: { enrollments: { _count: 'desc' } },
    })

  const { data: enrolledCourses, isLoading: isLoadingEnrolled } =
    Api.enrollment.findMany.useQuery({
      where: { userId: user?.id, courseId: { not: null } },
      include: { course: true, progresss: true },
    })

  const handleSearch = () => {
    router.push(
      `/organizations/${organization?.id}/courses?search=${searchKeyword}`,
    )
  }

  const handleCourseClick = (courseId: string) => {
    router.push(`/organizations/${organization?.id}/courses/${courseId}`)
  }

  return (
    <PageLayout layout="full-width">
      <Space
        direction="vertical"
        size="large"
        style={{
          width: '100%',
          maxWidth: 1200,
          margin: '0 auto',
          padding: '24px',
        }}
      >
        <Title level={2}>
          Welcome to {organization?.name} Learning Platform
        </Title>
        <Text>Discover and learn from our wide range of courses.</Text>

        <Input
          size="large"
          placeholder="Search for courses"
          prefix={<SearchOutlined />}
          value={searchKeyword}
          onChange={e => setSearchKeyword(e.target.value)}
          onPressEnter={handleSearch}
          style={{ marginBottom: 24 }}
        />

        <Title level={3}>Featured Courses</Title>
        <Row gutter={[16, 16]}>
          {isLoadingFeatured ? (
            <Col span={24}>Loading featured courses...</Col>
          ) : (
            featuredCourses?.map(course => (
              <Col xs={24} sm={12} md={8} key={course.id}>
                <Card
                  hoverable
                  onClick={() => handleCourseClick(course.id)}
                  cover={<BookOutlined style={{ fontSize: 48, padding: 24 }} />}
                >
                  <Card.Meta
                    title={course.title}
                    description={course.description}
                  />
                </Card>
              </Col>
            ))
          )}
        </Row>

        <Title level={3}>My Enrolled Courses</Title>
        <Row gutter={[16, 16]}>
          {isLoadingEnrolled ? (
            <Col span={24}>Loading enrolled courses...</Col>
          ) : enrolledCourses && enrolledCourses.length > 0 ? (
            enrolledCourses.map(enrollment => (
              <Col xs={24} sm={12} md={8} key={enrollment.id}>
                <Card
                  hoverable
                  onClick={() => handleCourseClick(enrollment.courseId)}
                  cover={
                    <TrophyOutlined style={{ fontSize: 48, padding: 24 }} />
                  }
                >
                  <Card.Meta
                    title={enrollment.course?.title}
                    description={
                      <Space direction="vertical" style={{ width: '100%' }}>
                        <Text>{enrollment.course?.description}</Text>
                        <Progress
                          percent={Math.round(
                            ((enrollment.progresss?.length || 0) /
                              (enrollment.course?.lessons?.length || 1)) *
                              100,
                          )}
                          status="active"
                        />
                      </Space>
                    }
                  />
                </Card>
              </Col>
            ))
          ) : (
            <Col span={24}>You haven't enrolled in any courses yet.</Col>
          )}
        </Row>
      </Space>
    </PageLayout>
  )
}
