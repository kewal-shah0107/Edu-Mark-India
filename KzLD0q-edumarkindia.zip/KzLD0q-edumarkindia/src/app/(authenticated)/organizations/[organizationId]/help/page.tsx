'use client'

import {
  Typography,
  Input,
  Button,
  List,
  Form,
  Card,
  Space,
  Row,
  Col,
} from 'antd'
import {
  QuestionCircleOutlined,
  SearchOutlined,
  SendOutlined,
} from '@ant-design/icons'
import { useState } from 'react'
const { Title, Text, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function HelpCenterPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user, checkOrganizationRole } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [searchTerm, setSearchTerm] = useState('')

  const isInstructor = checkOrganizationRole('instructor')

  const { data: faqs, isLoading: faqsLoading } = Api.faq.findMany.useQuery({
    where: { organizationId: params.organizationId },
  })

  const { mutateAsync: createSupportTicket } =
    Api.supportTicket.create.useMutation()

  const handleSearch = (value: string) => {
    setSearchTerm(value)
  }

  const filteredFaqs = faqs?.filter(
    faq =>
      faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleSubmitTicket = async (values: {
    subject: string
    message: string
  }) => {
    try {
      await createSupportTicket({
        data: {
          subject: values.subject,
          message: values.message,
          userId: user?.id,
          organizationId: params.organizationId,
        },
      })
      enqueueSnackbar('Support ticket submitted successfully', {
        variant: 'success',
      })
    } catch (error) {
      enqueueSnackbar('Failed to submit support ticket', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={18} lg={16} xl={14}>
          <Space direction="vertical" size="large" style={{ width: '100%' }}>
            <Title level={2}>Help Center</Title>
            <Paragraph>
              Welcome to our Help Center. Here you can find answers to
              frequently asked questions, search for specific topics, or submit
              a support ticket if you need further assistance.
            </Paragraph>

            {isInstructor && (
              <Card title="Instructor Tools">
                <Button
                  onClick={() =>
                    router.push(
                      `/organizations/${params.organizationId}/instructor/dashboard`,
                    )
                  }
                >
                  Update Course Information
                </Button>
              </Card>
            )}

            <Card title="Search Help Topics">
              <Input
                prefix={<SearchOutlined />}
                placeholder="Search for help topics"
                onChange={e => handleSearch(e.target.value)}
              />
            </Card>

            <Card title="Frequently Asked Questions">
              {faqsLoading ? (
                <Text>Loading FAQs...</Text>
              ) : (
                <List
                  dataSource={filteredFaqs}
                  renderItem={item => (
                    <List.Item>
                      <List.Item.Meta
                        avatar={<QuestionCircleOutlined />}
                        title={item.question}
                        description={item.answer}
                      />
                    </List.Item>
                  )}
                />
              )}
            </Card>

            <Card title="Submit a Support Ticket">
              <Form onFinish={handleSubmitTicket} layout="vertical">
                <Form.Item
                  name="subject"
                  label="Subject"
                  rules={[
                    { required: true, message: 'Please enter a subject' },
                  ]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  name="message"
                  label="Message"
                  rules={[
                    { required: true, message: 'Please enter your message' },
                  ]}
                >
                  <Input.TextArea rows={4} />
                </Form.Item>
                <Form.Item>
                  <Button
                    type="primary"
                    htmlType="submit"
                    icon={<SendOutlined />}
                  >
                    Submit Ticket
                  </Button>
                </Form.Item>
              </Form>
            </Card>
          </Space>
        </Col>
      </Row>
    </PageLayout>
  )
}
