'use client'

import { Typography, List, Button, Space, Card, Row, Col } from 'antd'
import {
  ShoppingCartOutlined,
  DeleteOutlined,
  ShoppingOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function CartPage() {
  const router = useRouter()
  const params = useParams<{ organizationId: string }>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const {
    data: cartItems,
    isLoading,
    refetch,
  } = Api.payment.findMany.useQuery({
    where: { userId: user?.id, status: 'IN_CART' },
    include: { course: true },
  })

  const { mutateAsync: removeFromCart } = Api.payment.delete.useMutation()

  const handleRemoveItem = async (itemId: string) => {
    try {
      await removeFromCart({ where: { id: itemId } })
      enqueueSnackbar('Item removed from cart', { variant: 'success' })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to remove item from cart', { variant: 'error' })
    }
  }

  const handleCheckout = () => {
    router.push(`/organizations/${params.organizationId}/checkout`)
  }

  const totalAmount =
    cartItems?.reduce((sum, item) => sum + (item.amount || 0), 0) || 0

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={16} lg={14} xl={12}>
          <Card>
            <Space direction="vertical" size="large" style={{ width: '100%' }}>
              <Title level={2}>
                <ShoppingCartOutlined /> Your Shopping Cart
              </Title>
              <Text>
                Review the items in your cart before proceeding to checkout.
              </Text>

              {isLoading ? (
                <Text>Loading cart items...</Text>
              ) : cartItems?.length === 0 ? (
                <Text>Your cart is empty.</Text>
              ) : (
                <>
                  <List
                    itemLayout="horizontal"
                    dataSource={cartItems}
                    renderItem={item => (
                      <List.Item
                        actions={[
                          <Button
                            key="remove"
                            type="text"
                            danger
                            icon={<DeleteOutlined />}
                            onClick={() => handleRemoveItem(item.id)}
                          >
                            Remove
                          </Button>,
                        ]}
                      >
                        <List.Item.Meta
                          title={item.course?.title}
                          description={`$${item.amount?.toFixed(2)}`}
                        />
                      </List.Item>
                    )}
                  />
                  <Space
                    direction="vertical"
                    size="small"
                    style={{ width: '100%' }}
                  >
                    <Text strong>Total: ${totalAmount.toFixed(2)}</Text>
                    <Button
                      type="primary"
                      icon={<ShoppingOutlined />}
                      onClick={handleCheckout}
                      size="large"
                    >
                      Proceed to Checkout
                    </Button>
                  </Space>
                </>
              )}
            </Space>
          </Card>
        </Col>
      </Row>
    </PageLayout>
  )
}
