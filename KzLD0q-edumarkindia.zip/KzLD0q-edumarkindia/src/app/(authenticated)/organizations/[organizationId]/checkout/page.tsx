'use client'

import { useState, useEffect } from 'react'
import {
  Typography,
  Form,
  Input,
  Button,
  Card,
  Space,
  Row,
  Col,
  Spin,
  InputNumber,
} from 'antd'
import {
  ShoppingCartOutlined,
  CreditCardOutlined,
  CheckCircleOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function CheckoutPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [form] = Form.useForm()

  const [selectedCourses, setSelectedCourses] = useState<any[]>([])
  const [totalAmount, setTotalAmount] = useState(0)

  const { data: courses, isLoading: coursesLoading } =
    Api.course.findMany.useQuery({
      where: { organizationId: params.organizationId },
    })

  const { mutateAsync: createPayment } = Api.payment.create.useMutation()

  useEffect(() => {
    if (courses) {
      // For demo purposes, we'll select all courses. In a real scenario, this would come from a cart or selection process
      setSelectedCourses(courses)
      setTotalAmount(
        courses.reduce((sum, course) => sum + (course.price || 0), 0),
      )
    }
  }, [courses])

  const onFinish = async (values: any) => {
    try {
      for (const course of selectedCourses) {
        await createPayment({
          data: {
            amount: course.price,
            status: 'completed',
            userId: user?.id || '',
            courseId: course.id,
          },
        })
      }
      enqueueSnackbar('Payment successful!', { variant: 'success' })
      router.push(`/organizations/${params.organizationId}/my-learning`)
    } catch (error) {
      enqueueSnackbar('Payment failed. Please try again.', { variant: 'error' })
    }
  }

  if (coursesLoading) {
    return (
      <PageLayout layout="full-width">
        <Spin size="large" />
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={16} lg={12}>
          <Space direction="vertical" size="large" style={{ width: '100%' }}>
            <Title level={2}>
              <ShoppingCartOutlined /> Checkout
            </Title>
            <Text>
              Complete your purchase to gain access to your selected courses.
            </Text>

            <Card title="Order Summary" style={{ width: '100%' }}>
              {selectedCourses?.map(course => (
                <div
                  key={course.id}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    marginBottom: '10px',
                  }}
                >
                  <Text>{course.title}</Text>
                  <Text strong>${course.price?.toString()}</Text>
                </div>
              ))}
              <div
                style={{
                  borderTop: '1px solid #f0f0f0',
                  paddingTop: '10px',
                  marginTop: '10px',
                }}
              >
                <Text strong>Total:</Text>
                <Text strong style={{ float: 'right' }}>
                  ${totalAmount.toString()}
                </Text>
              </div>
            </Card>

            <Card title="Payment Information" style={{ width: '100%' }}>
              <Form form={form} layout="vertical" onFinish={onFinish}>
                <Form.Item
                  name="cardNumber"
                  label="Card Number"
                  rules={[
                    {
                      required: true,
                      message: 'Please input your card number!',
                    },
                  ]}
                >
                  <Input
                    prefix={<CreditCardOutlined />}
                    placeholder="1234 5678 9012 3456"
                  />
                </Form.Item>
                <Form.Item
                  name="cardHolder"
                  label="Card Holder"
                  rules={[
                    {
                      required: true,
                      message: 'Please input the card holder name!',
                    },
                  ]}
                >
                  <Input placeholder="John Doe" />
                </Form.Item>
                <Row gutter={16}>
                  <Col span={12}>
                    <Form.Item
                      name="expiryDate"
                      label="Expiry Date"
                      rules={[
                        {
                          required: true,
                          message: 'Please input the expiry date!',
                        },
                      ]}
                    >
                      <Input placeholder="MM/YY" />
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      name="cvv"
                      label="CVV"
                      rules={[
                        { required: true, message: 'Please input the CVV!' },
                      ]}
                    >
                      <InputNumber
                        style={{ width: '100%' }}
                        placeholder="123"
                      />
                    </Form.Item>
                  </Col>
                </Row>
                <Form.Item>
                  <Button
                    type="primary"
                    htmlType="submit"
                    icon={<CheckCircleOutlined />}
                    block
                  >
                    Complete Purchase
                  </Button>
                </Form.Item>
              </Form>
            </Card>
          </Space>
        </Col>
      </Row>
    </PageLayout>
  )
}
