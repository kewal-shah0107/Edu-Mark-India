'use client'

import { Typography, Card, Button, Row, Col, Space, Spin, Empty } from 'antd'
import {
  DownloadOutlined,
  ShareAltOutlined,
  SyncOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function MyCertificatesPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const { data: enrollments, isLoading } = Api.enrollment.findMany.useQuery({
    where: { userId: user?.id },
    include: { certificates: true, course: true },
  })

  const handleDownload = (certificateUrl: string) => {
    window.open(certificateUrl, '_blank')
  }

  const handleShare = (certificateId: string) => {
    const shareUrl = `${window.location.origin}/certificates/${certificateId}`
    navigator.clipboard.writeText(shareUrl)
    enqueueSnackbar('Certificate link copied to clipboard', {
      variant: 'success',
    })
  }

  const handleRenew = (courseId: string) => {
    router.push(`/organizations/${params.organizationId}/courses/${courseId}`)
  }

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
        <Title level={2}>My Certificates</Title>
        <Text>View, download, and share your earned certificates.</Text>

        {isLoading ? (
          <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <Spin size="large" />
          </div>
        ) : enrollments && enrollments.length > 0 ? (
          <Row gutter={[16, 16]} style={{ marginTop: '24px' }}>
            {enrollments.map(enrollment =>
              enrollment.certificates?.map(certificate => (
                <Col xs={24} sm={12} md={8} lg={6} key={certificate.id}>
                  <Card
                    hoverable
                    cover={
                      <img
                        alt={`Certificate for ${enrollment.course?.title}`}
                        src={certificate.certificateUrl}
                      />
                    }
                    actions={[
                      <Button
                        icon={<DownloadOutlined />}
                        onClick={() =>
                          handleDownload(certificate.certificateUrl || '')
                        }
                      >
                        Download
                      </Button>,
                      <Button
                        icon={<ShareAltOutlined />}
                        onClick={() => handleShare(certificate.id)}
                      >
                        Share
                      </Button>,
                    ]}
                  >
                    <Card.Meta
                      title={enrollment.course?.title}
                      description={
                        <Space direction="vertical">
                          <Text>
                            Issued:{' '}
                            {dayjs(certificate.issueDate).format(
                              'MMMM D, YYYY',
                            )}
                          </Text>
                          {dayjs(certificate.issueDate)
                            .add(1, 'year')
                            .isBefore(dayjs()) && (
                            <Button
                              icon={<SyncOutlined />}
                              onClick={() => handleRenew(enrollment.courseId)}
                            >
                              Renew
                            </Button>
                          )}
                        </Space>
                      }
                    />
                  </Card>
                </Col>
              )),
            )}
          </Row>
        ) : (
          <Empty
            description="You haven't earned any certificates yet."
            style={{ marginTop: '50px' }}
          />
        )}
      </div>
    </PageLayout>
  )
}
