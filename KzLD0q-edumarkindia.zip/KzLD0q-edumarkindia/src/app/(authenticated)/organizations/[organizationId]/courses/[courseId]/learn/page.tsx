'use client'

import { Prisma } from '@prisma/client'
import { Typography, List, Card, Button, Space, Spin, Tabs, Input } from 'antd'
import {
  CheckCircleOutlined,
  PlayCircleOutlined,
  FileTextOutlined,
  QuestionCircleOutlined,
  MessageOutlined,
} from '@ant-design/icons'
import { useState } from 'react'
const { Title, Text, Paragraph } = Typography
const { TabPane } = Tabs
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function CourseContentPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [activeTab, setActiveTab] = useState('1')
  const [discussionMessage, setDiscussionMessage] = useState('')

  const courseId = params.courseId

  const { data: course, isLoading: courseLoading } =
    Api.course.findUnique.useQuery({
      where: { id: courseId },
      include: { lessons: true },
    })

  const { data: enrollment, isLoading: enrollmentLoading } =
    Api.enrollment.findFirst.useQuery({
      where: { userId: user?.id, courseId: courseId },
      include: { progresss: true },
    })

  const { mutateAsync: updateProgress } = Api.progress.update.useMutation()
  const { mutateAsync: createProgress } = Api.progress.create.useMutation()

  const handleLessonComplete = async (lessonId: string) => {
    const existingProgress = enrollment?.progresss?.find(
      p => p.lessonId === lessonId,
    )
    if (existingProgress) {
      await updateProgress({
        where: { id: existingProgress.id },
        data: { status: 'completed', completionDate: new Date().toISOString() },
      })
    } else {
      await createProgress({
        data: {
          status: 'completed',
          completionDate: new Date().toISOString(),
          enrollment: { connect: { id: enrollment?.id } },
          lesson: { connect: { id: lessonId } },
        },
      })
    }
    enqueueSnackbar('Lesson marked as complete', { variant: 'success' })
  }

  const handleDiscussionSubmit = () => {
    // Here you would typically send the message to your backend
    // For now, we'll just show a success message
    enqueueSnackbar('Message posted to discussion', { variant: 'success' })
    setDiscussionMessage('')
  }

  if (courseLoading || enrollmentLoading) {
    return (
      <PageLayout layout="full-width">
        <Spin size="large" />
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
        <Title level={2}>{course?.title}</Title>
        <Paragraph>{course?.description}</Paragraph>

        <Tabs activeKey={activeTab} onChange={setActiveTab}>
          <TabPane tab="Course Content" key="1">
            <List
              dataSource={course?.lessons}
              renderItem={(lesson: any) => (
                <List.Item>
                  <Card
                    title={lesson.title}
                    extra={
                      <Button
                        type="primary"
                        icon={<CheckCircleOutlined />}
                        onClick={() => handleLessonComplete(lesson.id)}
                      >
                        Mark Complete
                      </Button>
                    }
                  >
                    <Space>
                      {lesson.content?.includes('video') && (
                        <PlayCircleOutlined />
                      )}
                      {lesson.content?.includes('reading') && (
                        <FileTextOutlined />
                      )}
                      {lesson.content?.includes('quiz') && (
                        <QuestionCircleOutlined />
                      )}
                      <Text>{lesson.content}</Text>
                    </Space>
                  </Card>
                </List.Item>
              )}
            />
          </TabPane>
          <TabPane tab="Discussion" key="2">
            <List
              // This would typically be fetched from your backend
              dataSource={[
                { user: 'John Doe', message: 'Great course!' },
                {
                  user: 'Jane Smith',
                  message: 'I have a question about lesson 3...',
                },
              ]}
              renderItem={(item: any) => (
                <List.Item>
                  <Card>
                    <Text strong>{item.user}: </Text>
                    <Text>{item.message}</Text>
                  </Card>
                </List.Item>
              )}
            />
            <Input.TextArea
              rows={4}
              value={discussionMessage}
              onChange={e => setDiscussionMessage(e.target.value)}
              placeholder="Type your message here..."
              style={{ marginTop: '20px' }}
            />
            <Button
              type="primary"
              icon={<MessageOutlined />}
              onClick={handleDiscussionSubmit}
              style={{ marginTop: '10px' }}
            >
              Post Message
            </Button>
          </TabPane>
        </Tabs>
      </div>
    </PageLayout>
  )
}
