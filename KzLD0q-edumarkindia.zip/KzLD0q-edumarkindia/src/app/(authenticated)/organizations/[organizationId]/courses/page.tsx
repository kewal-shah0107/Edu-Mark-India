'use client'

import { Prisma } from '@prisma/client'
import { Typography, Card, Row, Col, Select, Spin, Empty } from 'antd'
import { StarOutlined, DollarOutlined, FireOutlined } from '@ant-design/icons'
import { useState } from 'react'
const { Title, Text } = Typography
const { Option } = Select
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function CourseCatalogPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user, organization } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [sortBy, setSortBy] = useState<string>('popularity')

  const { data: courses, isLoading } = Api.course.findMany.useQuery({
    where: { organizationId: params.organizationId },
    include: { reviews: true, enrollments: true },
  })

  const handleSortChange = (value: string) => {
    setSortBy(value)
  }

  const sortedCourses = courses?.slice().sort((a, b) => {
    switch (sortBy) {
      case 'popularity':
        return b.enrollments.length - a.enrollments.length
      case 'rating':
        const aRating =
          a.reviews.reduce((acc, review) => acc + (review.rating || 0), 0) /
            a.reviews.length || 0
        const bRating =
          b.reviews.reduce((acc, review) => acc + (review.rating || 0), 0) /
            b.reviews.length || 0
        return bRating - aRating
      case 'price':
        // Assuming there's a price field in the course model
        return (a.price || 0) - (b.price || 0)
      default:
        return 0
    }
  })

  const handleCourseClick = (courseId: string) => {
    router.push(`/organizations/${params.organizationId}/courses/${courseId}`)
  }

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
        <Title level={2}>Course Catalog</Title>
        <Text>Browse all available courses in {organization?.name}</Text>

        <div style={{ marginTop: 24, marginBottom: 24 }}>
          <Select
            defaultValue="popularity"
            style={{ width: 200 }}
            onChange={handleSortChange}
          >
            <Option value="popularity">Sort by Popularity</Option>
            <Option value="rating">Sort by Rating</Option>
            <Option value="price">Sort by Price</Option>
          </Select>
        </div>

        {isLoading ? (
          <Spin size="large" />
        ) : sortedCourses && sortedCourses.length > 0 ? (
          <Row gutter={[16, 16]}>
            {sortedCourses.map(course => (
              <Col xs={24} sm={12} md={8} lg={6} key={course.id}>
                <Card
                  hoverable
                  onClick={() => handleCourseClick(course.id)}
                  cover={
                    <img
                      alt={course.title}
                      src={
                        course.coverImage ||
                        'https://via.placeholder.com/300x200'
                      }
                      style={{ height: 200, objectFit: 'cover' }}
                    />
                  }
                >
                  <Card.Meta
                    title={course.title}
                    description={
                      <>
                        <Text ellipsis style={{ display: 'block' }}>
                          {course.description}
                        </Text>
                        <div style={{ marginTop: 8 }}>
                          <FireOutlined style={{ marginRight: 8 }} />
                          {course.enrollments.length} enrolled
                        </div>
                        <div>
                          <StarOutlined style={{ marginRight: 8 }} />
                          {(
                            course.reviews.reduce(
                              (acc, review) => acc + (review.rating || 0),
                              0,
                            ) / course.reviews.length || 0
                          ).toFixed(1)}
                        </div>
                        <div>
                          <DollarOutlined style={{ marginRight: 8 }} />
                          {course.price
                            ? `$${course.price.toString()}`
                            : 'Free'}
                        </div>
                      </>
                    }
                  />
                </Card>
              </Col>
            ))}
          </Row>
        ) : (
          <Empty description="No courses found" />
        )}
      </div>
    </PageLayout>
  )
}
