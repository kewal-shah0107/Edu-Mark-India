'use client'

import {
  Typography,
  Card,
  Row,
  Col,
  Button,
  Rate,
  List,
  Avatar,
  Spin,
} from 'antd'
import { BookOutlined, UserOutlined, DollarOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function CourseDetailsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const courseId = params.courseId
  const organizationId = params.organizationId

  const { data: course, isLoading } = Api.course.findUnique.useQuery({
    where: { id: courseId },
    include: {
      organization: true,
      lessons: true,
      reviews: { include: { user: true } },
    },
  })

  const { mutateAsync: createEnrollment } = Api.enrollment.create.useMutation()

  const handleEnroll = async () => {
    try {
      await createEnrollment({
        data: {
          userId: user?.id || '',
          courseId: courseId,
          status: 'ENROLLED',
        },
      })
      enqueueSnackbar('Successfully enrolled in the course', {
        variant: 'success',
      })
      router.push(`/organizations/${organizationId}/courses/${courseId}/learn`)
    } catch (error) {
      enqueueSnackbar('Failed to enroll in the course', { variant: 'error' })
    }
  }

  if (isLoading) {
    return (
      <PageLayout layout="full-width">
        <Spin size="large" />
      </PageLayout>
    )
  }

  if (!course) {
    return (
      <PageLayout layout="full-width">
        <Title level={2}>Course not found</Title>
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={18} lg={16}>
          <Title level={2}>{course.title}</Title>
          <Paragraph>{course.description}</Paragraph>

          <Card title="Course Information" style={{ marginBottom: '20px' }}>
            <Row gutter={[16, 16]}>
              <Col span={8}>
                <Text strong>
                  <BookOutlined /> Lessons:
                </Text>{' '}
                {course.lessons?.length}
              </Col>
              <Col span={8}>
                <Text strong>
                  <UserOutlined /> Instructor:
                </Text>{' '}
                {course.organization?.name}
              </Col>
              <Col span={8}>
                <Text strong>
                  <DollarOutlined /> Price:
                </Text>{' '}
                $99.99
              </Col>
            </Row>
          </Card>

          <Card title="Course Syllabus" style={{ marginBottom: '20px' }}>
            <List
              dataSource={course.lessons}
              renderItem={(lesson, index) => (
                <List.Item>
                  <Text>{`${index + 1}. ${lesson.title}`}</Text>
                </List.Item>
              )}
            />
          </Card>

          <Card title="Reviews" style={{ marginBottom: '20px' }}>
            <List
              itemLayout="horizontal"
              dataSource={course.reviews}
              renderItem={review => (
                <List.Item>
                  <List.Item.Meta
                    avatar={
                      <Avatar
                        src={review.user?.pictureUrl}
                        icon={<UserOutlined />}
                      />
                    }
                    title={<Text>{review.user?.name}</Text>}
                    description={
                      <>
                        <Rate disabled defaultValue={review.rating || 0} />
                        <Paragraph>{review.comment}</Paragraph>
                        <Text type="secondary">
                          {dayjs(review.dateCreated).format('MMMM D, YYYY')}
                        </Text>
                      </>
                    }
                  />
                </List.Item>
              )}
            />
          </Card>

          <Button type="primary" size="large" onClick={handleEnroll}>
            Enroll Now
          </Button>
        </Col>
      </Row>
    </PageLayout>
  )
}
