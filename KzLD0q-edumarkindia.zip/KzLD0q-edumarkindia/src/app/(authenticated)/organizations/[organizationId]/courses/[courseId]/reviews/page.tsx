'use client'

import { Prisma } from '@prisma/client'
import {
  Typography,
  Rate,
  Input,
  Button,
  List,
  Card,
  Space,
  Row,
  Col,
} from 'antd'
import { StarOutlined, CommentOutlined } from '@ant-design/icons'
import { useState } from 'react'
const { Title, Text, Paragraph } = Typography
const { TextArea } = Input
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function UserReviewsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const [newReview, setNewReview] = useState({ rating: 0, comment: '' })

  const { data: course, isLoading: courseLoading } =
    Api.course.findUnique.useQuery({
      where: { id: params.courseId },
      include: { reviews: { include: { user: true } } },
    })

  const { data: userEnrollment } = Api.enrollment.findFirst.useQuery({
    where: { userId: user?.id, courseId: params.courseId },
  })

  const { mutateAsync: createReview } = Api.review.create.useMutation()

  const handleRatingChange = (value: number) => {
    setNewReview(prev => ({ ...prev, rating: value }))
  }

  const handleCommentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNewReview(prev => ({ ...prev, comment: e.target.value }))
  }

  const handleSubmitReview = async () => {
    if (!user) {
      enqueueSnackbar('You must be logged in to submit a review', {
        variant: 'error',
      })
      return
    }

    if (!userEnrollment) {
      enqueueSnackbar('You must be enrolled in the course to submit a review', {
        variant: 'error',
      })
      return
    }

    if (newReview.rating === 0) {
      enqueueSnackbar('Please provide a rating', { variant: 'error' })
      return
    }

    try {
      await createReview({
        data: {
          rating: newReview.rating,
          comment: newReview.comment,
          userId: user.id,
          courseId: params.courseId,
        },
      })
      enqueueSnackbar('Review submitted successfully', { variant: 'success' })
      setNewReview({ rating: 0, comment: '' })
      router.refresh()
    } catch (error) {
      enqueueSnackbar('Failed to submit review', { variant: 'error' })
    }
  }

  if (courseLoading) {
    return (
      <PageLayout layout="full-width">
        <Text>Loading...</Text>
      </PageLayout>
    )
  }

  if (!course) {
    return (
      <PageLayout layout="full-width">
        <Text>Course not found</Text>
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={16} lg={14} xl={12}>
          <Space direction="vertical" size="large" style={{ width: '100%' }}>
            <Title level={2}>Reviews for {course.title}</Title>
            <Paragraph>Read and write reviews for this course.</Paragraph>

            {userEnrollment && (
              <Card title="Write a Review">
                <Space
                  direction="vertical"
                  size="middle"
                  style={{ width: '100%' }}
                >
                  <Rate
                    allowHalf
                    value={newReview.rating}
                    onChange={handleRatingChange}
                  />
                  <TextArea
                    rows={4}
                    value={newReview.comment}
                    onChange={handleCommentChange}
                    placeholder="Write your review here..."
                  />
                  <Button type="primary" onClick={handleSubmitReview}>
                    Submit Review
                  </Button>
                </Space>
              </Card>
            )}

            <List
              itemLayout="vertical"
              dataSource={course.reviews}
              renderItem={review => (
                <List.Item>
                  <Card>
                    <Space direction="vertical">
                      <Space>
                        <StarOutlined />
                        <Text strong>{review.rating?.toString()}/5</Text>
                      </Space>
                      <Text>{review.user?.name}</Text>
                      <Paragraph>
                        <CommentOutlined /> {review.comment}
                      </Paragraph>
                    </Space>
                  </Card>
                </List.Item>
              )}
            />
          </Space>
        </Col>
      </Row>
    </PageLayout>
  )
}
