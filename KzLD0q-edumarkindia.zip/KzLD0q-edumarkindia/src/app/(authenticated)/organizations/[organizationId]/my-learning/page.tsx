'use client'

import { Typography, Card, Progress, Button, Row, Col, Spin } from 'antd'
import { BookOutlined, PlayCircleOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function MyLearningPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const { data: enrollments, isLoading } = Api.enrollment.findMany.useQuery({
    where: { userId: user?.id },
    include: {
      course: true,
      progresss: { include: { lesson: true } },
    },
  })

  const handleResumeCourse = (courseId: string) => {
    router.push(
      `/organizations/${params.organizationId}/courses/${courseId}/learn`,
    )
  }

  const calculateProgress = (enrollment: any) => {
    const totalLessons = enrollment.course.lessons?.length || 0
    const completedLessons =
      enrollment.progresss?.filter((p: any) => p.status === 'completed')
        .length || 0
    return Math.round((completedLessons / totalLessons) * 100)
  }

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
        <Title level={2}>My Learning</Title>
        <Text>Track your progress and resume your courses</Text>

        {isLoading ? (
          <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <Spin size="large" />
          </div>
        ) : (
          <Row gutter={[16, 16]} style={{ marginTop: '24px' }}>
            {enrollments?.map(enrollment => (
              <Col xs={24} sm={12} md={8} key={enrollment.id}>
                <Card
                  hoverable
                  cover={
                    <img
                      alt={enrollment.course?.title}
                      src={
                        enrollment.course?.pictureUrl ||
                        'https://via.placeholder.com/300x200'
                      }
                      style={{ height: 200, objectFit: 'cover' }}
                    />
                  }
                >
                  <Card.Meta
                    title={enrollment.course?.title}
                    description={
                      <>
                        <Text>
                          <BookOutlined /> Enrolled on:{' '}
                          {dayjs(enrollment.enrollmentDate).format(
                            'MMMM D, YYYY',
                          )}
                        </Text>
                        <Progress
                          percent={calculateProgress(enrollment)}
                          status="active"
                        />
                      </>
                    }
                  />
                  <Button
                    type="primary"
                    icon={<PlayCircleOutlined />}
                    onClick={() => handleResumeCourse(enrollment.course?.id)}
                    style={{ marginTop: '16px', width: '100%' }}
                  >
                    Resume Course
                  </Button>
                </Card>
              </Col>
            ))}
          </Row>
        )}

        {!isLoading && enrollments?.length === 0 && (
          <Text>You haven't enrolled in any courses yet.</Text>
        )}
      </div>
    </PageLayout>
  )
}
