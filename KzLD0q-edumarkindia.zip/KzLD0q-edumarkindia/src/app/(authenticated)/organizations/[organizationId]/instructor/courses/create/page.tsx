'use client'

import { useState } from 'react'
import {
  Typography,
  Form,
  Input,
  InputNumber,
  Button,
  Upload,
  Space,
  Row,
  Col,
} from 'antd'
import { UploadOutlined, PlusOutlined, DeleteOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function CreateCoursePage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user, organization } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [form] = Form.useForm()
  const [materials, setMaterials] = useState<{ name: string; url: string }[]>(
    [],
  )

  const { mutateAsync: createCourse } = Api.course.create.useMutation()
  const { mutateAsync: upload } = useUploadPublic()

  const handleSubmit = async (values: any) => {
    try {
      const course = await createCourse({
        data: {
          title: values.title,
          description: values.description,
          organizationId: organization?.id || '',
        },
      })

      enqueueSnackbar('Course created successfully!', { variant: 'success' })
      router.push(
        `/organizations/${params.organizationId}/instructor/courses/${course.id}/edit`,
      )
    } catch (error) {
      enqueueSnackbar('Failed to create course', { variant: 'error' })
    }
  }

  const handleUpload = async (file: File) => {
    try {
      const { url } = await upload({ file })
      setMaterials([...materials, { name: file.name, url }])
    } catch (error) {
      enqueueSnackbar('Failed to upload file', { variant: 'error' })
    }
  }

  const removeMaterial = (index: number) => {
    setMaterials(materials.filter((_, i) => i !== index))
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={16} lg={12}>
          <Title level={2}>Create a New Course</Title>
          <Text>
            As an instructor, you can create a new course, upload materials, and
            set pricing.
          </Text>

          <Form
            form={form}
            layout="vertical"
            onFinish={handleSubmit}
            style={{ marginTop: '2rem' }}
          >
            <Form.Item
              name="title"
              label="Course Title"
              rules={[
                { required: true, message: 'Please input the course title!' },
              ]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="description"
              label="Course Description"
              rules={[
                {
                  required: true,
                  message: 'Please input the course description!',
                },
              ]}
            >
              <Input.TextArea rows={4} />
            </Form.Item>

            <Form.Item label="Course Materials">
              <Upload
                beforeUpload={file => {
                  handleUpload(file)
                  return false
                }}
              >
                <Button icon={<UploadOutlined />}>Click to Upload</Button>
              </Upload>
            </Form.Item>

            {materials.length > 0 && (
              <Form.Item label="Uploaded Materials">
                <Space direction="vertical">
                  {materials.map((material, index) => (
                    <Space key={index}>
                      <Text>{material.name}</Text>
                      <Button
                        type="text"
                        danger
                        icon={<DeleteOutlined />}
                        onClick={() => removeMaterial(index)}
                      />
                    </Space>
                  ))}
                </Space>
              </Form.Item>
            )}

            <Form.Item
              name="price"
              label="Course Price"
              rules={[
                { required: true, message: 'Please input the course price!' },
              ]}
            >
              <InputNumber
                min={0}
                precision={2}
                prefix="$"
                style={{ width: '100%' }}
              />
            </Form.Item>

            <Form.Item>
              <Button type="primary" htmlType="submit" icon={<PlusOutlined />}>
                Create Course
              </Button>
            </Form.Item>
          </Form>
        </Col>
      </Row>
    </PageLayout>
  )
}
