'use client'

import { Prisma } from '@prisma/client'
import { useState, useEffect } from 'react'
import { Typography, Form, Input, Button, Switch, Space, Row, Col } from 'antd'
import {
  EditOutlined,
  SaveOutlined,
  GlobalOutlined,
  LockOutlined,
} from '@ant-design/icons'
const { Title, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function EditCoursePage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user, checkOrganizationRole } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [form] = Form.useForm()

  const [course, setCourse] = useState<Prisma.CourseGetPayload<{
    include: { lessons: true }
  }> | null>(null)
  const [isPublished, setIsPublished] = useState(false)

  const {
    data: courseData,
    isLoading,
    refetch,
  } = Api.course.findUnique.useQuery({
    where: { id: params.courseId },
    include: { lessons: true },
  })

  const { mutateAsync: updateCourse } = Api.course.update.useMutation()

  useEffect(() => {
    if (courseData) {
      setCourse(courseData)
      setIsPublished(courseData.status === 'PUBLISHED')
      form.setFieldsValue({
        title: courseData.title,
        description: courseData.description,
      })
    }
  }, [courseData, form])

  const handleSubmit = async (values: any) => {
    try {
      await updateCourse({
        where: { id: params.courseId },
        data: {
          ...values,
          status: isPublished ? 'PUBLISHED' : 'DRAFT',
        },
      })
      enqueueSnackbar('Course updated successfully', { variant: 'success' })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to update course', { variant: 'error' })
    }
  }

  const togglePublish = async () => {
    try {
      const newStatus = !isPublished
      await updateCourse({
        where: { id: params.courseId },
        data: { status: newStatus ? 'PUBLISHED' : 'DRAFT' },
      })
      setIsPublished(newStatus)
      enqueueSnackbar(
        `Course ${newStatus ? 'published' : 'unpublished'} successfully`,
        { variant: 'success' },
      )
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to update course status', { variant: 'error' })
    }
  }

  if (isLoading || !course) {
    return <PageLayout layout="full-width">Loading...</PageLayout>
  }

  if (!checkOrganizationRole('INSTRUCTOR')) {
    router.push(`/organizations/${params.organizationId}/home`)
    return null
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={16} lg={12}>
          <Title level={2}>Edit Course</Title>
          <Paragraph>
            Modify your course content and manage its publication status.
          </Paragraph>

          <Form form={form} onFinish={handleSubmit} layout="vertical">
            <Form.Item
              name="title"
              label="Course Title"
              rules={[
                { required: true, message: 'Please input the course title!' },
              ]}
            >
              <Input prefix={<EditOutlined />} />
            </Form.Item>

            <Form.Item
              name="description"
              label="Course Description"
              rules={[
                {
                  required: true,
                  message: 'Please input the course description!',
                },
              ]}
            >
              <Input.TextArea rows={4} />
            </Form.Item>

            <Form.Item>
              <Space>
                <Button
                  type="primary"
                  htmlType="submit"
                  icon={<SaveOutlined />}
                >
                  Save Changes
                </Button>
                <Switch
                  checkedChildren={<GlobalOutlined />}
                  unCheckedChildren={<LockOutlined />}
                  checked={isPublished}
                  onChange={togglePublish}
                />
                <span>{isPublished ? 'Published' : 'Draft'}</span>
              </Space>
            </Form.Item>
          </Form>

          <Title level={3} style={{ marginTop: '2rem' }}>
            Lessons
          </Title>
          {course.lessons?.map((lesson, index) => (
            <Paragraph key={lesson.id}>
              {index + 1}. {lesson.title}
            </Paragraph>
          ))}
          <Button
            onClick={() =>
              router.push(
                `/organizations/${params.organizationId}/instructor/courses/${params.courseId}/lessons/create`,
              )
            }
            style={{ marginTop: '1rem' }}
          >
            Add New Lesson
          </Button>
        </Col>
      </Row>
    </PageLayout>
  )
}
