'use client'

import {
  Typography,
  Card,
  Row,
  Col,
  Statistic,
  List,
  Button,
  Space,
} from 'antd'
import {
  BookOutlined,
  QuestionCircleOutlined,
  StarOutlined,
  EditOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function InstructorDashboardPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user, organization } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const { data: courses, isLoading: coursesLoading } =
    Api.course.findMany.useQuery({
      where: { organizationId: params.organizationId },
      include: { enrollments: true, reviews: true },
    })

  const handleManageCourse = (courseId: string) => {
    router.push(
      `/organizations/${params.organizationId}/instructor/courses/${courseId}/edit`,
    )
  }

  const handleCreateCourse = () => {
    router.push(
      `/organizations/${params.organizationId}/instructor/courses/create`,
    )
  }

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
        <Title level={2}>Instructor Dashboard</Title>
        <Text>
          Welcome back, {user?.name}! Here's an overview of your courses and
          performance.
        </Text>

        <Row gutter={[16, 16]} style={{ marginTop: '24px' }}>
          <Col xs={24} sm={8}>
            <Card>
              <Statistic
                title="Total Courses"
                value={courses?.length || 0}
                prefix={<BookOutlined />}
              />
            </Card>
          </Col>
          <Col xs={24} sm={8}>
            <Card>
              <Statistic
                title="Total Students"
                value={courses?.reduce(
                  (acc, course) => acc + (course.enrollments?.length || 0),
                  0,
                )}
                prefix={<UserOutlined />}
              />
            </Card>
          </Col>
          <Col xs={24} sm={8}>
            <Card>
              <Statistic
                title="Average Rating"
                value={
                  courses?.reduce((acc, course) => {
                    const courseRating =
                      course.reviews?.reduce(
                        (sum, review) => sum + (review.rating || 0),
                        0,
                      ) || 0
                    return acc + courseRating / (course.reviews?.length || 1)
                  }, 0) / (courses?.length || 1)
                }
                precision={2}
                prefix={<StarOutlined />}
              />
            </Card>
          </Col>
        </Row>

        <Title level={3} style={{ marginTop: '32px' }}>
          Your Courses
        </Title>
        <List
          loading={coursesLoading}
          dataSource={courses}
          renderItem={course => (
            <List.Item
              actions={[
                <Button
                  key="manage"
                  icon={<EditOutlined />}
                  onClick={() => handleManageCourse(course.id)}
                >
                  Manage
                </Button>,
              ]}
            >
              <List.Item.Meta
                title={course.title}
                description={
                  <Space direction="vertical">
                    <Text>Students: {course.enrollments?.length || 0}</Text>
                    <Text>
                      Average Rating:{' '}
                      {(course.reviews?.reduce(
                        (sum, review) => sum + (review.rating || 0),
                        0,
                      ) || 0) / (course.reviews?.length || 1)}
                    </Text>
                    <Text>
                      Last Updated:{' '}
                      {dayjs(course.dateUpdated).format('MMMM D, YYYY')}
                    </Text>
                  </Space>
                }
              />
            </List.Item>
          )}
        />

        <Button
          type="primary"
          icon={<PlusOutlined />}
          style={{ marginTop: '24px' }}
          onClick={handleCreateCourse}
        >
          Create New Course
        </Button>

        <Title level={3} style={{ marginTop: '32px' }}>
          Recent Student Questions
        </Title>
        <List
          dataSource={[]} // Replace with actual data when available
          renderItem={item => (
            <List.Item>
              <List.Item.Meta
                avatar={<QuestionCircleOutlined />}
                title={item.question}
                description={`From: ${item.studentName} - Course: ${item.courseName}`}
              />
              <Button>Reply</Button>
            </List.Item>
          )}
          locale={{ emptyText: 'No recent questions' }}
        />
      </div>
    </PageLayout>
  )
}
