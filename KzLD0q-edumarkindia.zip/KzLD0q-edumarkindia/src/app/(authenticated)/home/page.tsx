'use client'

import { Typography, Card, Select, Row, Col, Input } from 'antd'
import { FilterOutlined, BookOutlined } from '@ant-design/icons'
import { useState } from 'react'
const { Title, Paragraph } = Typography
const { Option } = Select
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function HomePage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const [category, setCategory] = useState<string>('')
  const [difficulty, setDifficulty] = useState<string>('')
  const [maxPrice, setMaxPrice] = useState<number | null>(null)

  const { data: courses, isLoading } = Api.course.findMany.useQuery({
    where: {
      ...(category && { category }),
      ...(difficulty && { difficulty }),
      ...(maxPrice !== null && { price: { lte: maxPrice } }),
    },
  })

  const handleCategoryChange = (value: string) => {
    setCategory(value)
  }

  const handleDifficultyChange = (value: string) => {
    setDifficulty(value)
  }

  const handleMaxPriceChange = (value: number | null) => {
    setMaxPrice(value)
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={18} lg={16} xl={14}>
          <Card>
            <Title level={2}>Welcome to Our Learning Platform</Title>
            <Paragraph>
              Discover a world of knowledge with our diverse range of courses.
              Use the filters below to find the perfect course for you!
            </Paragraph>

            <Row gutter={[16, 16]} align="middle">
              <Col span={8}>
                <Select
                  style={{ width: '100%' }}
                  placeholder="Select Category"
                  onChange={handleCategoryChange}
                  value={category}
                >
                  <Option value="">All Categories</Option>
                  <Option value="programming">Programming</Option>
                  <Option value="design">Design</Option>
                  <Option value="business">Business</Option>
                </Select>
              </Col>
              <Col span={8}>
                <Select
                  style={{ width: '100%' }}
                  placeholder="Select Difficulty"
                  onChange={handleDifficultyChange}
                  value={difficulty}
                >
                  <Option value="">All Levels</Option>
                  <Option value="beginner">Beginner</Option>
                  <Option value="intermediate">Intermediate</Option>
                  <Option value="advanced">Advanced</Option>
                </Select>
              </Col>
              <Col span={8}>
                <Input
                  type="number"
                  placeholder="Max Price"
                  onChange={e =>
                    handleMaxPriceChange(
                      e.target.value ? Number(e.target.value) : null,
                    )
                  }
                  value={maxPrice !== null ? maxPrice : ''}
                />
              </Col>
            </Row>

            <Title level={3} style={{ marginTop: '24px' }}>
              <FilterOutlined /> Filtered Courses
            </Title>

            {isLoading ? (
              <Paragraph>Loading courses...</Paragraph>
            ) : (
              <Row gutter={[16, 16]}>
                {courses?.map(course => (
                  <Col key={course.id} xs={24} sm={12} md={8} lg={6}>
                    <Card
                      hoverable
                      onClick={() =>
                        router.push(
                          `/organizations/${params.organizationId}/courses/${course.id}`,
                        )
                      }
                    >
                      <BookOutlined
                        style={{ fontSize: '24px', marginBottom: '8px' }}
                      />
                      <Title level={4}>{course.title}</Title>
                      <Paragraph ellipsis={{ rows: 2 }}>
                        {course.description}
                      </Paragraph>
                    </Card>
                  </Col>
                ))}
              </Row>
            )}

            {courses?.length === 0 && (
              <Paragraph>
                No courses found matching your criteria. Try adjusting your
                filters.
              </Paragraph>
            )}
          </Card>
        </Col>
      </Row>
    </PageLayout>
  )
}
