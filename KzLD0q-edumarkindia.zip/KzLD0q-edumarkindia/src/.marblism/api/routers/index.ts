/* eslint-disable */
import type { unsetMarker, AnyRouter, AnyRootConfig, CreateRouterInner, Procedure, ProcedureBuilder, ProcedureParams, ProcedureRouterRecord, ProcedureType } from "@trpc/server";
import type { PrismaClient } from "@prisma/client";
import createCourseRouter from "./Course.router";
import createLessonRouter from "./Lesson.router";
import createEnrollmentRouter from "./Enrollment.router";
import createProgressRouter from "./Progress.router";
import createCertificateRouter from "./Certificate.router";
import createReviewRouter from "./Review.router";
import createPaymentRouter from "./Payment.router";
import createOrganizationRouter from "./Organization.router";
import createOrganizationRoleRouter from "./OrganizationRole.router";
import createUserRouter from "./User.router";
import createAccountRouter from "./Account.router";
import createSessionRouter from "./Session.router";
import { ClientType as CourseClientType } from "./Course.router";
import { ClientType as LessonClientType } from "./Lesson.router";
import { ClientType as EnrollmentClientType } from "./Enrollment.router";
import { ClientType as ProgressClientType } from "./Progress.router";
import { ClientType as CertificateClientType } from "./Certificate.router";
import { ClientType as ReviewClientType } from "./Review.router";
import { ClientType as PaymentClientType } from "./Payment.router";
import { ClientType as OrganizationClientType } from "./Organization.router";
import { ClientType as OrganizationRoleClientType } from "./OrganizationRole.router";
import { ClientType as UserClientType } from "./User.router";
import { ClientType as AccountClientType } from "./Account.router";
import { ClientType as SessionClientType } from "./Session.router";

export type BaseConfig = AnyRootConfig;

export type RouterFactory<Config extends BaseConfig> = <
    ProcRouterRecord extends ProcedureRouterRecord
>(
    procedures: ProcRouterRecord
) => CreateRouterInner<Config, ProcRouterRecord>;

export type UnsetMarker = typeof unsetMarker;

export type ProcBuilder<Config extends BaseConfig> = ProcedureBuilder<
    ProcedureParams<Config, any, any, any, UnsetMarker, UnsetMarker, any>
>;

export function db(ctx: any) {
    if (!ctx.prisma) {
        throw new Error('Missing "prisma" field in trpc context');
    }
    return ctx.prisma as PrismaClient;
}

export function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({
        course: createCourseRouter(router, procedure),
        lesson: createLessonRouter(router, procedure),
        enrollment: createEnrollmentRouter(router, procedure),
        progress: createProgressRouter(router, procedure),
        certificate: createCertificateRouter(router, procedure),
        review: createReviewRouter(router, procedure),
        payment: createPaymentRouter(router, procedure),
        organization: createOrganizationRouter(router, procedure),
        organizationRole: createOrganizationRoleRouter(router, procedure),
        user: createUserRouter(router, procedure),
        account: createAccountRouter(router, procedure),
        session: createSessionRouter(router, procedure),
    }
    );
}

export interface ClientType<AppRouter extends AnyRouter> {
    course: CourseClientType<AppRouter>;
    lesson: LessonClientType<AppRouter>;
    enrollment: EnrollmentClientType<AppRouter>;
    progress: ProgressClientType<AppRouter>;
    certificate: CertificateClientType<AppRouter>;
    review: ReviewClientType<AppRouter>;
    payment: PaymentClientType<AppRouter>;
    organization: OrganizationClientType<AppRouter>;
    organizationRole: OrganizationRoleClientType<AppRouter>;
    user: UserClientType<AppRouter>;
    account: AccountClientType<AppRouter>;
    session: SessionClientType<AppRouter>;
}
