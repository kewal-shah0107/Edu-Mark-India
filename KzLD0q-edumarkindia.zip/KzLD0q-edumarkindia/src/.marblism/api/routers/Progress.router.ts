/* eslint-disable */
import { type RouterFactory, type ProcBuilder, type BaseConfig, db } from ".";
import * as _Schema from '@zenstackhq/runtime/zod/input';
const $Schema: typeof _Schema = (_Schema as any).default ?? _Schema;
import { checkRead, checkMutate } from '../helper';
import type { Prisma } from '@prisma/client';
import type { UseTRPCMutationOptions, UseTRPCMutationResult, UseTRPCQueryOptions, UseTRPCQueryResult, UseTRPCInfiniteQueryOptions, UseTRPCInfiniteQueryResult } from '@trpc/react-query/shared';
import type { TRPCClientErrorLike } from '@trpc/client';
import type { AnyRouter } from '@trpc/server';

export default function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({

        createMany: procedure.input($Schema.ProgressInputSchema.createMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).progress.createMany(input as any))),

        create: procedure.input($Schema.ProgressInputSchema.create).mutation(async ({ ctx, input }) => checkMutate(db(ctx).progress.create(input as any))),

        deleteMany: procedure.input($Schema.ProgressInputSchema.deleteMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).progress.deleteMany(input as any))),

        delete: procedure.input($Schema.ProgressInputSchema.delete).mutation(async ({ ctx, input }) => checkMutate(db(ctx).progress.delete(input as any))),

        findFirst: procedure.input($Schema.ProgressInputSchema.findFirst).query(({ ctx, input }) => checkRead(db(ctx).progress.findFirst(input as any))),

        findMany: procedure.input($Schema.ProgressInputSchema.findMany).query(({ ctx, input }) => checkRead(db(ctx).progress.findMany(input as any))),

        findUnique: procedure.input($Schema.ProgressInputSchema.findUnique).query(({ ctx, input }) => checkRead(db(ctx).progress.findUnique(input as any))),

        updateMany: procedure.input($Schema.ProgressInputSchema.updateMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).progress.updateMany(input as any))),

        update: procedure.input($Schema.ProgressInputSchema.update).mutation(async ({ ctx, input }) => checkMutate(db(ctx).progress.update(input as any))),

    }
    );
}

export interface ClientType<AppRouter extends AnyRouter, Context = AppRouter['_def']['_config']['$types']['ctx']> {
    createMany: {

        useMutation: <T extends Prisma.ProgressCreateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.ProgressCreateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.ProgressCreateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.ProgressCreateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    create: {

        useMutation: <T extends Prisma.ProgressCreateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.ProgressCreateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.ProgressGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.ProgressGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.ProgressCreateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.ProgressCreateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.ProgressGetPayload<T>, Context>) => Promise<Prisma.ProgressGetPayload<T>>
            };

    };
    deleteMany: {

        useMutation: <T extends Prisma.ProgressDeleteManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.ProgressDeleteManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.ProgressDeleteManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.ProgressDeleteManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    delete: {

        useMutation: <T extends Prisma.ProgressDeleteArgs>(opts?: UseTRPCMutationOptions<
            Prisma.ProgressDeleteArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.ProgressGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.ProgressGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.ProgressDeleteArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.ProgressDeleteArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.ProgressGetPayload<T>, Context>) => Promise<Prisma.ProgressGetPayload<T>>
            };

    };
    findFirst: {

        useQuery: <T extends Prisma.ProgressFindFirstArgs, TData = Prisma.ProgressGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.ProgressFindFirstArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.ProgressGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.ProgressFindFirstArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.ProgressFindFirstArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.ProgressGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.ProgressGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findMany: {

        useQuery: <T extends Prisma.ProgressFindManyArgs, TData = Array<Prisma.ProgressGetPayload<T>>>(
            input: Prisma.SelectSubset<T, Prisma.ProgressFindManyArgs>,
            opts?: UseTRPCQueryOptions<string, T, Array<Prisma.ProgressGetPayload<T>>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.ProgressFindManyArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.ProgressFindManyArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Array<Prisma.ProgressGetPayload<T>>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Array<Prisma.ProgressGetPayload<T>>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findUnique: {

        useQuery: <T extends Prisma.ProgressFindUniqueArgs, TData = Prisma.ProgressGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.ProgressFindUniqueArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.ProgressGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.ProgressFindUniqueArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.ProgressFindUniqueArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.ProgressGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.ProgressGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    updateMany: {

        useMutation: <T extends Prisma.ProgressUpdateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.ProgressUpdateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.ProgressUpdateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.ProgressUpdateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    update: {

        useMutation: <T extends Prisma.ProgressUpdateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.ProgressUpdateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.ProgressGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.ProgressGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.ProgressUpdateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.ProgressUpdateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.ProgressGetPayload<T>, Context>) => Promise<Prisma.ProgressGetPayload<T>>
            };

    };
}
