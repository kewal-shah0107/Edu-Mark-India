/* eslint-disable */
import { type RouterFactory, type ProcBuilder, type BaseConfig, db } from ".";
import * as _Schema from '@zenstackhq/runtime/zod/input';
const $Schema: typeof _Schema = (_Schema as any).default ?? _Schema;
import { checkRead, checkMutate } from '../helper';
import type { Prisma } from '@prisma/client';
import type { UseTRPCMutationOptions, UseTRPCMutationResult, UseTRPCQueryOptions, UseTRPCQueryResult, UseTRPCInfiniteQueryOptions, UseTRPCInfiniteQueryResult } from '@trpc/react-query/shared';
import type { TRPCClientErrorLike } from '@trpc/client';
import type { AnyRouter } from '@trpc/server';

export default function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({

        createMany: procedure.input($Schema.LessonInputSchema.createMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).lesson.createMany(input as any))),

        create: procedure.input($Schema.LessonInputSchema.create).mutation(async ({ ctx, input }) => checkMutate(db(ctx).lesson.create(input as any))),

        deleteMany: procedure.input($Schema.LessonInputSchema.deleteMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).lesson.deleteMany(input as any))),

        delete: procedure.input($Schema.LessonInputSchema.delete).mutation(async ({ ctx, input }) => checkMutate(db(ctx).lesson.delete(input as any))),

        findFirst: procedure.input($Schema.LessonInputSchema.findFirst).query(({ ctx, input }) => checkRead(db(ctx).lesson.findFirst(input as any))),

        findMany: procedure.input($Schema.LessonInputSchema.findMany).query(({ ctx, input }) => checkRead(db(ctx).lesson.findMany(input as any))),

        findUnique: procedure.input($Schema.LessonInputSchema.findUnique).query(({ ctx, input }) => checkRead(db(ctx).lesson.findUnique(input as any))),

        updateMany: procedure.input($Schema.LessonInputSchema.updateMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).lesson.updateMany(input as any))),

        update: procedure.input($Schema.LessonInputSchema.update).mutation(async ({ ctx, input }) => checkMutate(db(ctx).lesson.update(input as any))),

    }
    );
}

export interface ClientType<AppRouter extends AnyRouter, Context = AppRouter['_def']['_config']['$types']['ctx']> {
    createMany: {

        useMutation: <T extends Prisma.LessonCreateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.LessonCreateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.LessonCreateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.LessonCreateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    create: {

        useMutation: <T extends Prisma.LessonCreateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.LessonCreateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.LessonGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.LessonGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.LessonCreateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.LessonCreateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.LessonGetPayload<T>, Context>) => Promise<Prisma.LessonGetPayload<T>>
            };

    };
    deleteMany: {

        useMutation: <T extends Prisma.LessonDeleteManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.LessonDeleteManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.LessonDeleteManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.LessonDeleteManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    delete: {

        useMutation: <T extends Prisma.LessonDeleteArgs>(opts?: UseTRPCMutationOptions<
            Prisma.LessonDeleteArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.LessonGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.LessonGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.LessonDeleteArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.LessonDeleteArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.LessonGetPayload<T>, Context>) => Promise<Prisma.LessonGetPayload<T>>
            };

    };
    findFirst: {

        useQuery: <T extends Prisma.LessonFindFirstArgs, TData = Prisma.LessonGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.LessonFindFirstArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.LessonGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.LessonFindFirstArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.LessonFindFirstArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.LessonGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.LessonGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findMany: {

        useQuery: <T extends Prisma.LessonFindManyArgs, TData = Array<Prisma.LessonGetPayload<T>>>(
            input: Prisma.SelectSubset<T, Prisma.LessonFindManyArgs>,
            opts?: UseTRPCQueryOptions<string, T, Array<Prisma.LessonGetPayload<T>>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.LessonFindManyArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.LessonFindManyArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Array<Prisma.LessonGetPayload<T>>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Array<Prisma.LessonGetPayload<T>>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findUnique: {

        useQuery: <T extends Prisma.LessonFindUniqueArgs, TData = Prisma.LessonGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.LessonFindUniqueArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.LessonGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.LessonFindUniqueArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.LessonFindUniqueArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.LessonGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.LessonGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    updateMany: {

        useMutation: <T extends Prisma.LessonUpdateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.LessonUpdateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.LessonUpdateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.LessonUpdateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    update: {

        useMutation: <T extends Prisma.LessonUpdateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.LessonUpdateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.LessonGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.LessonGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.LessonUpdateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.LessonUpdateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.LessonGetPayload<T>, Context>) => Promise<Prisma.LessonGetPayload<T>>
            };

    };
}
